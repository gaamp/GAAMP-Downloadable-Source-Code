#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/stat.h>

#ifdef _WIN32
#include <direct.h>
#include <windows.h>
#else
#include <unistd.h>	//for linux
#endif

#include "nlopt.h"
#include "ff.h"

#define MAX_ATOM_MOL	(500)
//#define N_MAX_WAT	(100)
#define MAX_N_CONF	(100)

#define b0_H_O_EXP	(0.9572)	// tip3 and exp
#define theta0_H_O_H_EXP	(104.52)	// tip3, exp?

//#define b0_H_O_MP2	(0.958825)
//#define theta0_H_O_H_MP2	(104.2242)

#define b0_H_O_HF	(0.9474)		// optimized by HF/6-31G*
#define theta0_H_O_H_HF	(105.5395)

#define HARTREE_To_KCAL	(627.509469)
#define radian	(57.29577951308232088)
#define radianInv	(0.017453292519943295)
#define PI	(3.14159265358979323846)
#define PI2	(6.28318530717958647692)

#ifndef MINAB
#define MINAB 
#define	min(a,b)	((a<b)?(a):(b))
#define	max(a,b)	((a>b)?(a):(b))
#endif


//start	data and functions related with job scheduler
#define MAX_JOB	(1024)

enum { IDLE, BUSY };
enum { Job_ToRun, Job_Running, Job_Done };

class CWORKER
{
public:
	int JobID, Status, nCore;
	char szInput[256], szOutput[256];

	void Start_Job(int CoreNum, int ID, char szGjf[], char szOut[]);	// start running a job
	int Get_Job_Status(void);
	void Update_Core_Number_Input_File(void);
};

CWORKER *pWorker;
int nJob=0, nJobDone=0, nWorker=0, nCore_Per_Node=1;
int JobStatus[MAX_JOB], Acceptor_List[MAX_JOB], AcceptorIdx_List[MAX_JOB], Theta_List[MAX_JOB];
char szDirList[MAX_JOB][256], szInputList[MAX_JOB][256], szOutputList[MAX_JOB][256];
double Para_MM_Save[MAX_JOB][2];
const char szGAUSS_SCRDIR[]="GAUSS_SCRDIR";
char szGAUSS_SCRDIR_Base[256];

void RunAllJobs(void);
int Get_First_Available_Worker(void);
void Exatract_All_Info_QM_1D_Scan(void);
//end	data and functions related with job scheduler


FILE *fFile_Run_Log;
char szLogName[256]="log-gen-HBond-A.txt";
char szQMParaFile[]="../QM-para.txt";
char szMMForceField[]="mol.prm";

char szQM_Level_Int_E_Dimer_Cmd[512]="%mem=200MB\n%nproc=2\n#P HF/6-31G* nosymm SCF=Tight counterpoise=2\n\nMol-Water Dimer\n\n0,1 0,1 0,1 \n";	// kbt - small queue
char szQM_Level_Int_E_Dimer_Opt_Cmd[512]="%mem=200MB\n%nproc=2\n#P HF/6-31G* nosymm SCF=Tight counterpoise=2 opt=ModRedundant\n\nMol-Water Dimer\n\n0,1 0,1 0,1 \n";	// kbt - small queue
char szQM_Level_Int_E_Single_Mol_Cmd[512]="%mem=200MB\n%nproc=2\n#P HF/6-31G* nosymm SCF=Tight\n\nMol/Water\n\n0,1\n";	// kbt - small queue
char szQM_Level_Int_E_Single_Wat_Cmd[512]="%mem=200MB\n%nproc=2\n#P HF/6-31G* nosymm SCF=Tight\n\nMol/Water\n\n0,1\n";	// kbt - small queue

char szExe_G09[256];
char szExe_Cale_MM[256];
char szMyPath[]="../mypath.txt";
char szMolWat_E_Int[]="E-mol-wat.txt";
char szCGList[]="cg-list.txt";
char szCurDir[256];
char szWorkDir[256];

double x_Wat_MM[3], y_Wat_MM[3], z_Wat_MM[3];	// to store the optimized MM water configurations
double x_Wat_QM[3], y_Wat_QM[3], z_Wat_QM[3];	// to store the optimized MM water configurations

int Idx_Acceptor, ActiveAtom, Neighbor;

#define N_PARA	(2)
double Para_List[N_PARA], Grad_List[N_PARA], Para_Best[N_PARA], Low_Bound[N_PARA], Up_Bound[N_PARA];
char szElemName[MAX_ATOM_MOL][8];

int n_Atom_In_Mol;
int ResIDMol[MAX_ATOM_MOL];
int Idx_O_Wat, Idx_H1_Wat, Idx_H2_Wat;

double x_ReadIn[MAX_ATOM_MOL], y_ReadIn[MAX_ATOM_MOL], z_ReadIn[MAX_ATOM_MOL];

double x_Opt_QM[MAX_ATOM_MOL], y_Opt_QM[MAX_ATOM_MOL], z_Opt_QM[MAX_ATOM_MOL];
double r_Emin_MM=0.0, r_Emin_QM=0.0, E_Min_MM=0.0, E_Min_QM=0.0;
//double E_Min_MM_Shifted=0.0;

char szNameMolCRD[256];
char szAtomNameMol[MAX_ATOM_MOL][8], szResNameMol[MAX_ATOM_MOL][8];
//double x_Mol[MAX_ATOM_MOL], y_Mol[MAX_ATOM_MOL], z_Mol[MAX_ATOM_MOL];
double *x_Mol, *y_Mol, *z_Mol;
double E_Min=1.0E20;

double H1_Wat_x, H1_Wat_y, H1_Wat_z;
double O_Wat_x, O_Wat_y, O_Wat_z;
double H2_Wat_x, H2_Wat_y, H2_Wat_z;

double E_Dimer_Int, E_Dimer, E_Dimer_Min, E_Dimer_Far;

#define R_DUMMY_1	(1.5)
#define R_DUMMY_2	(1.5)
double x_Dummy_1, y_Dummy_1, z_Dummy_1, x_Dummy_1_Save, y_Dummy_1_Save, z_Dummy_1_Save, x_Dummy_1_Org, y_Dummy_1_Org, z_Dummy_1_Org;
double x_Dummy_2, y_Dummy_2, z_Dummy_2, x_Dummy_2_Save, y_Dummy_2_Save, z_Dummy_2_Save, x_Dummy_2_Org, y_Dummy_2_Org, z_Dummy_2_Org;
double x_Dummy_3, y_Dummy_3, z_Dummy_3;
double v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, v_x_X1_Acceptor_Save, v_y_X1_Acceptor_Save, v_z_X1_Acceptor_Save;
double Para_Save_for_QM[N_PARA];
int theta, theta_Save;

CForceField ForceField;
CMol Mol, Dimer;

int netcharge_mol;
void Get_Netcharge_From_Xpsf(void);

char szName_Gaussian[256]="dimer.gjf";
char szFileElem[]="elem-list.txt";
char szFilePsf[]="mol.xpsf";
char szFileDimerPsf[]="mol-wat.xpsf";
char szFileCrd[]="mol-opt.crd";

int Is_N[MAX_ATOM_MOL], Is_O[MAX_ATOM_MOL], Is_F[MAX_ATOM_MOL], Is_S[MAX_ATOM_MOL];
int Bond_Count[MAX_ATOM_MOL], BondList[MAX_ATOM_MOL][4];


void ReadMolCRD(void);
void GenerateWater(void);
double Normalizex(double& vect_x, double& vect_y, double& vect_z);
void OutputCRD(void);
void Generate_Gaussian_Input(void);
void Generate_Ini_Configuration(void);
double Optimize_Water_Pose(void);
void Output_Optimize_Water_Pose_QM(void);

void Quit_With_Error_Msg(char szMsg[]);
void Make_List_H_Acceptor(void);
void GetBondList(int Idx);
int Is_N_Planar(int Idx, double& x, double& y, double& z);
int Is_Three_Atoms_Colinear(int ia, int ib, int ic);

void SaveDummyAtoms(void);
void RestoreDummyAtoms(void);

void Generate_Dummy_Atoms_Bond_1(int Idx);
void Generate_Dummy_Atoms_Bond_2(int Idx);
void Generate_Dummy_Atoms_Bond_3(int Idx);
void Generate_Dummy_Atoms_Bond_Perp(int Idx);	// Sign = 0 / 1, positive or negative
void Generate_Dummy_Atoms_Bond_Perp_Flipped(int Idx);	// Sign = 0 / 1, positive or negative
void Rotate_Dummy_Atoms(int Idx, double theta);

double Extract_E_Gaussian_Output(char szFileName[], char szTag[]);
double Get_E_Mol_Water_Far_QM();
void Get_EXE_Path(char szExeFile[], char szExePath[]);
void Cal_r_Dependent_E(int MM_Orientation);
double Cal_Dist_Two_Atoms(int ia, int ib);

// to generate xyz with r, theta, phi based on three atoms, A, B, C
void Gen_xyz(double x_A, double y_A, double z_A, 
			 double x_B, double y_B, double z_B, 
			 double x_C, double y_C, double z_C, 
			 double r, double theta, double phi, 
			 double& x_D, double& y_D, double& z_D);


void Replace_NewLine(char szBuff[]);
int Split_Into_Two_String(char szBuff[], char str1[], char str2[]);
void Setup_QM_Level(void);

int To_Find_Tag(FILE *fIn, char szFileName[], char szTag[], char szLine[]);
int Skip_N_Line(FILE *fIn, char szFileName[], int n);
void Replace_D_E(char szStr[]);


int Iteration;
static int FailCount=0;
double Callback_Eval_Gradient(unsigned n, const double *x, double *grad, void *my_func_data);
double CalObjectiveFunction(void);
double CalGradient(void);

extern int FindString(char szBuff[], char szTag[]);

void ReadPreviousCG(void);

double rmsfit(double *x1, double *y1, double *z1, double *x2, double *y2, double *z2, int n);
void quatfit(double *x1, double *y1, double *z1, double *x2, double *y2, double *z2, int n);
void jacobi(int n, int np, double a[5][5], double d[5], double v[5][5], double b[5], double z[5]);
double CalRMSD(double *x1, double *y1, double *z1, double *x2, double *y2, double *z2, int n);
double Dot_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b);
void Cross_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b, double& x_Product, double& y_Product, double& z_Product);

void Extract_All_E_Dimer(void);


int main(int argc, char *argv[])
{
	int i, j, Phi=0, AcceptorSelect;
	int ToGenerate_Water;
	FILE *fOut;
	char szCmd[256], ErrorMsg[256], *szEnv;
        char dum1[20],dum2[20];
  
        FILE *aopt;
        double energyTreshold;
        int goPerpendicular;

        goPerpendicular = 0;
        energyTreshold = -2.0;    
   
        aopt = fopen("../acceptor_option.user","r");
        if (aopt != NULL) {
          fscanf(aopt, "%s %s \n",dum1, dum2);
          fclose(aopt);
          goPerpendicular  = atoi(dum1);
          energyTreshold = atof(dum2);
        }

	getcwd(szCurDir, 256);

	fFile_Run_Log = fopen(szLogName, "a+");

	szEnv = getenv(szGAUSS_SCRDIR);
	if (szEnv == NULL) {
		Quit_With_Error_Msg("Environment variable $GAUSS_SCRDIR is NOT set.\nQuit\n");
	}
	strcpy(szGAUSS_SCRDIR_Base, szEnv);
	
	fseek(fFile_Run_Log, SEEK_END, 0);
	Get_EXE_Path("G09_EXE_PATH", szExe_G09);
	
	ForceField.ReadForceField(szMMForceField);
	Dimer.ReadPSF(szFileDimerPsf, 1);
	Dimer.AssignForceFieldParameters(&ForceField);
	
	Mol.ReadPSF(szFilePsf, 0);
	Mol.AssignForceFieldParameters(&ForceField);
	Mol.ReadCRD(szFileCrd);

	for(i=0; i<Mol.nAtom; i++)	{	// Readin QM optimized structure
		x_ReadIn[i] = Mol.x[i];
		y_ReadIn[i] = Mol.y[i];
		z_ReadIn[i] = Mol.z[i];
	}
	
	n_Atom_In_Mol = Mol.nAtom;
	ReadPreviousCG();
	Get_Netcharge_From_Xpsf();

	for(i=0; i<Mol.nAtom; i++)	{	// !!! the number of atom
		Dimer.x[i] = Mol.x[i];
		Dimer.y[i] = Mol.y[i];
		Dimer.z[i] = Mol.z[i];

		x_Opt_QM[i] = Mol.x[i];
		y_Opt_QM[i] = Mol.y[i];
		z_Opt_QM[i] = Mol.z[i];
	}
	x_Mol = Mol.x;
	y_Mol = Mol.y;
	z_Mol = Mol.z;

	Idx_O_Wat = Mol.nAtom;
	Idx_H1_Wat=Idx_O_Wat+1;
	Idx_H2_Wat=Idx_O_Wat+2;

	Setup_QM_Level();

	Make_List_H_Acceptor();

	E_Dimer_Far = Get_E_Mol_Water_Far_QM();

	if(argc == 3)	{	// only to generate the list of acceptors
		AcceptorSelect = atoi(argv[2]);
	}
	else	{
		AcceptorSelect = -1;	// a null acceptor
	}

	Idx_Acceptor = 0;
	for(i=0; i<n_Atom_In_Mol; i++)	{
		ToGenerate_Water = 0;
		Neighbor = 0xFFFFFFF;	// an invalid number
		if(Is_N[i])	{
			if(Bond_Count[i] == 3)	{	//
				if(Is_N_Planar(i, H1_Wat_x, H1_Wat_y, H1_Wat_z)==0)	{	// skip if planar since the hydrogen bond is weak
					ToGenerate_Water = 1;
					Generate_Dummy_Atoms_Bond_3(i);
				}
			}
			else if(Bond_Count[i] == 2)	{
				ToGenerate_Water = 1;
				Generate_Dummy_Atoms_Bond_2(i);
			}
			else if(Bond_Count[i] == 1)	{
				Generate_Dummy_Atoms_Bond_1(i);
				ToGenerate_Water = 1;
			}
		}
		else if(Is_O[i])	{
			if(Bond_Count[i] == 2)	{	//
				Generate_Dummy_Atoms_Bond_2(i);
			}
			else if(Bond_Count[i] == 1)	{
				Generate_Dummy_Atoms_Bond_1(i);
			}
			else	{
				sprintf(ErrorMsg, "mol_H_acceptor.cpp> Unknow type of O atom.\nQuit\n");
				Quit_With_Error_Msg(ErrorMsg);
			}
			ToGenerate_Water = 1;
		}
/*
		else if(Is_S[i])	{
			if(Bond_Count[i] == 2)	{	//
				Generate_Dummy_Atoms_Bond_2(i);
				ToGenerate_Water = 1;
			}
			else if(Bond_Count[i] == 1)	{
				Generate_Dummy_Atoms_Bond_1(i);
				ToGenerate_Water = 1;
			}
			else	{
//				sprintf(ErrorMsg, "mol_H_acceptor.cpp> Unknow type of S atom.\nQuit\n");
//				Quit_With_Error_Msg(ErrorMsg);
			}
		}
*/
		else if(Is_F[i])	{
			if(Bond_Count[i] == 1)	{
				Generate_Dummy_Atoms_Bond_1(i);
			}
			else	{
				sprintf(ErrorMsg, "mol_H_acceptor.cpp> Unknow type of F atom.\nQuit\n");
				Quit_With_Error_Msg(ErrorMsg);
			}
			ToGenerate_Water = 1;
		}

		if(ToGenerate_Water)	{
			ActiveAtom = i;
			SaveDummyAtoms();
			x_Dummy_1_Org = x_Dummy_1;	y_Dummy_1_Org = y_Dummy_1;	z_Dummy_1_Org = z_Dummy_1;
			x_Dummy_2_Org = x_Dummy_2;	y_Dummy_2_Org = y_Dummy_2;	z_Dummy_2_Org = z_Dummy_2;

			sprintf(szWorkDir, "%s/dat-acceptor-%d-%d", szCurDir, Idx_Acceptor+1, ActiveAtom+1);
			sprintf(szCmd, "mkdir %s", szWorkDir);
			system(szCmd);
			chdir(szWorkDir);

			E_Min_MM = 1.0E100;
			r_Emin_MM = 1.0E100;
			theta = 0;
			for(Phi=0; Phi<360; Phi+=60)	{
				Para_List[0] = 1.9;
				Para_List[1] = ((Phi+15)%360)*radianInv;
				Optimize_Water_Pose();

				if( E_Dimer_Min < E_Min_MM )	{	// save the water with lowest interaction energy
					E_Min_MM = E_Dimer_Min;
					r_Emin_MM = Para_Best[0];
					SaveDummyAtoms();
					memcpy(Para_Save_for_QM, Para_Best, sizeof(double)*N_PARA);
					memcpy(Para_List, Para_Best, sizeof(double)*N_PARA);
					theta_Save = theta;

//					Para_List[0] += 0.2;	// shifted distance
//					E_Min_MM_Shifted = CalObjectiveFunction();
//					Para_List[0] = Para_Best[0];	// shifted back
//					GenerateWater();
//					printf("E_Shifted = %lf\n", E_Min_MM_Shifted);
				}

				char szName[256];
				sprintf(szName, "theta-%d-cluster-%d.pdb", theta, Phi/60 + 1);
				Dimer.SavePdb(szName);
			}

                        printf("MinEMM: %f, forcePerpendicular= %d, energyTreshold = %f\n",E_Min_MM,goPerpendicular, energyTreshold);

                        int angleForOrientation;
                        if (goPerpendicular) 
                        {
                          E_Min_MM=999;
                          angleForOrientation = goPerpendicular;
                        } else  
                        {
                          angleForOrientation = 30;
                        }
                        // Eliot modified to have option for Alex and Fang-Yu to have a perpendicular oriantation. 
			if( ( (Bond_Count[i] <= 2) && (E_Min_MM > energyTreshold ) && (goPerpendicular == 0)) || (goPerpendicular) )	{	// to generate water along a perp orientation
				for(theta=-angleForOrientation; theta<=angleForOrientation; theta+=2*angleForOrientation)	{	
//				for(theta=-45; theta<=45; theta+=90)	{	// only -45 and 45
					Rotate_Dummy_Atoms(i, 1.0*theta);	// generate dummy atoms 
					
					for(Phi=0; Phi<360; Phi+=60)	{
						Para_List[0] = 1.9;
						Para_List[1] = ((Phi+15)%360)*radianInv;
						
						Optimize_Water_Pose();
//						printf("theta = %3d  Phi = %22.16lf\n", theta, Para_Best[1]*radian);
						
						if( E_Dimer_Min < E_Min_MM )	{	// save the water with lowest interaction energy
							E_Min_MM = E_Dimer_Min;
							r_Emin_MM = Para_Best[0];
							SaveDummyAtoms();
							memcpy(Para_Save_for_QM, Para_Best, sizeof(double)*N_PARA);
							memcpy(Para_List, Para_Best, sizeof(double)*N_PARA);
							theta_Save = theta;

//							Para_List[0] += 0.2;	// shifted distance
//							E_Min_MM_Shifted = CalObjectiveFunction();
//							Para_List[0] = Para_Best[0];	// shifted back
//							GenerateWater();
						}
						
						char szName[256];
						sprintf(szName, "theta-%d-cluster-%d.pdb", theta, Phi/60 + 1);
						Dimer.SavePdb(szName);

					}				
				}
			}

			RestoreDummyAtoms();
			fprintf(fFile_Run_Log, "mol_H_acceptor.cpp> %2d H acceptor: %2d atom %3s MM, E_min = %7.4lf r_min = %7.4lf\n", 
				Idx_Acceptor+1, i+1, szElemName[i], E_Min_MM, r_Emin_MM);
			fprintf(fFile_Run_Log, "theta = %3d  r = %22.16lf phi = %22.16lf\n", 
				theta_Save, Para_Save_for_QM[0], Para_Save_for_QM[1]);

// ELIOT modified for having another default cutoff
			if(E_Min_MM > energyTreshold)	{	// skip this acceptor if the interaction is too weak
                                printf("Skipping acceptor as interaction is too week (%f kcal/mol)\n",E_Min_MM);
				Idx_Acceptor++;
				continue;
			}


			fOut = fopen("mol-waters.pdb", "w");
			for(j=0; j<n_Atom_In_Mol; j++)	{
				fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
					j+1, Dimer.AtomName[j], "MOL", 1, Dimer.x[j], Dimer.y[j], Dimer.z[j]);
			}
			fflush(fOut);

			sprintf(szWorkDir, "%s/dat-acceptor-%d-%d/QM", szCurDir, Idx_Acceptor+1, ActiveAtom+1);
			sprintf(szCmd, "mkdir %s", szWorkDir);
			system(szCmd);
			chdir(szWorkDir);


			strcpy(szDirList[nJob], szWorkDir);
			Acceptor_List[nJob] = ActiveAtom;
			Theta_List[nJob] = theta_Save;
			Para_MM_Save[nJob][0] = Para_Save_for_QM[0];
			Para_MM_Save[nJob][1] = Para_Save_for_QM[1];
			AcceptorIdx_List[nJob] = Idx_Acceptor;
			
			Output_Optimize_Water_Pose_QM();	// to write input file for Gaussian 
			nJob++;

			Idx_Acceptor++;
		}
	}
	
	RunAllJobs();
	chdir(szCurDir);
	Extract_All_E_Dimer();

	fclose(fFile_Run_Log);



	return 0;
}

void Extract_All_E_Dimer(void)
{
	int i, ReadItem, AtomNum, iTmp;
	char szName_Result[256], szLine[256], szStr_Energy[256], *ReadLine;
	FILE *fIn, *fEnergy, *fWater;

	for(i=0; i<nJob; i++)	{
		chdir(szDirList[i]);

		//start	to extract the optimized geometry of water
		strcpy(szName_Result, szOutputList[i]);
		fIn = fopen(szName_Result, "r");
		
		
		if(fIn == NULL)	{
			Quit_With_Error_Msg("Fail to open the output of the optimization of dimer.\nQuit\n");
		}
		To_Find_Tag(fIn, szName_Result, " Optimization completed", szLine);
		To_Find_Tag(fIn, szName_Result, " orientation:", szLine);
		Skip_N_Line(fIn, szName_Result, 4+n_Atom_In_Mol);	// including the coordinates of X1 and X2.
		
		while(1)	{
			if(feof(fIn))	{
				Quit_With_Error_Msg("Reaching the end of the file. Error in extracting the coordinates of water in Acceptor.\n");
			}
			ReadLine = fgets(szLine, 256, fIn);
			ReadItem = sscanf(szLine, "%d %d", &iTmp, &AtomNum);
			if( ReadItem !=2 )	{
				Quit_With_Error_Msg("Error in extracting the coordinates of water in Acceptor.\n");
			}
			if(AtomNum == -1)	{	// -1 means dummy atom !!!!
			}
			else	{
				ReadItem = sscanf(szLine+34, "%lf %lf %lf", &H1_Wat_x, &H1_Wat_y, &H1_Wat_z);
				if(ReadItem != 3)	{
					Quit_With_Error_Msg("Fail to get the coordinate of H1 from the output of Gaussian for restrained optimization of dimer.\nQuit\n");
				}
				else	{
					break;
				}
			}
		}
		
		while(1)	{
			if(feof(fIn))	{
				Quit_With_Error_Msg("Reaching the end of the file. Error in extracting the coordinates of water in Acceptor.\n");
			}
			ReadLine = fgets(szLine, 256, fIn);
			ReadItem = sscanf(szLine, "%d %d", &iTmp, &AtomNum);
			if( ReadItem !=2 )	{
				Quit_With_Error_Msg("Error in extracting the coordinates of water in Acceptor.\n");
			}
			if(AtomNum == -1)	{	// -1 means dummy atom !!!!
			}
			else	{
				ReadItem = sscanf(szLine+34, "%lf %lf %lf", &O_Wat_x, &O_Wat_y, &O_Wat_z);
				if(ReadItem != 3)	{
					Quit_With_Error_Msg("Fail to get the coordinate of OH2 from the output of Gaussian for restrained optimization of dimer.\nQuit\n");
				}
				else	{
					break;
				}
			}
		}
		
		while(1)	{
			if(feof(fIn))	{
				Quit_With_Error_Msg("Reaching the end of the file. Error in extracting the coordinates of water in Acceptor.\n");
			}
			ReadLine = fgets(szLine, 256, fIn);
			ReadItem = sscanf(szLine, "%d %d", &iTmp, &AtomNum);
			if( ReadItem !=2 )	{
				Quit_With_Error_Msg("Error in extracting the coordinates of water in Acceptor.\n");
			}
			if(AtomNum == -1)	{	// -1 means dummy atom !!!!
			}
			else	{
				ReadItem = sscanf(szLine+34, "%lf %lf %lf", &H2_Wat_x, &H2_Wat_y, &H2_Wat_z);
				if(ReadItem != 3)	{
					Quit_With_Error_Msg("Fail to get the coordinate of H2 from the output of Gaussian for restrained optimization of dimer.\nQuit\n");
				}
				else	{
					break;
				}
			}
		}
		
		//end	to extract the optimized geometry of water 
		
		x_Opt_QM[n_Atom_In_Mol+0] = O_Wat_x;	y_Opt_QM[n_Atom_In_Mol+0] = O_Wat_y;	z_Opt_QM[n_Atom_In_Mol+0] = O_Wat_z;
		x_Opt_QM[n_Atom_In_Mol+1] = H1_Wat_x;	y_Opt_QM[n_Atom_In_Mol+1] = H1_Wat_y;	z_Opt_QM[n_Atom_In_Mol+1] = H1_Wat_z;
		x_Opt_QM[n_Atom_In_Mol+2] = H2_Wat_x;	y_Opt_QM[n_Atom_In_Mol+2] = H2_Wat_y;	z_Opt_QM[n_Atom_In_Mol+2] = H2_Wat_z;
		
		//start	to extract the optimized geometry of water
		E_Min = 1.0E100;
		fseek(fIn, 0, SEEK_SET);
		while(1)	{
			if(feof(fIn))	{
				break;
			}
			ReadLine = fgets(szLine, 256, fIn);
			if(ReadLine == NULL)	{
				break;
			}
			else	{
				if(FindString(szLine, "SCF Done:  E(RHF)") >= 0)	{
					sscanf(szLine+20, "%s", szStr_Energy);
					Replace_D_E(szStr_Energy);
					ReadItem = sscanf(szStr_Energy, "%lf", &E_Min);
				}
			}
			
		}
		//end	to extract the optimized geometry of water
		
		fclose(fIn);
		
		E_Min_QM = (E_Min-E_Dimer_Far)*HARTREE_To_KCAL;
		memcpy(Dimer.x+n_Atom_In_Mol, x_Opt_QM+n_Atom_In_Mol, sizeof(double)*3);	// update the water configuration with lowest E_int
		memcpy(Dimer.y+n_Atom_In_Mol, y_Opt_QM+n_Atom_In_Mol, sizeof(double)*3);
		memcpy(Dimer.z+n_Atom_In_Mol, z_Opt_QM+n_Atom_In_Mol, sizeof(double)*3);
		
		memcpy(x_Wat_QM, x_Opt_QM+n_Atom_In_Mol, sizeof(double)*3);	// update the water configuration with lowest E_int
		memcpy(y_Wat_QM, y_Opt_QM+n_Atom_In_Mol, sizeof(double)*3);
		memcpy(z_Wat_QM, z_Opt_QM+n_Atom_In_Mol, sizeof(double)*3);
		
		r_Emin_QM = Cal_Dist_Two_Atoms(Acceptor_List[i], n_Atom_In_Mol+1);	// donor - H1 / H2
		
		fWater = fopen("../mol-waters.pdb", "a+");
		fseek(fWater, 0, SEEK_END);
		fprintf(fWater, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
			n_Atom_In_Mol+1, "OH2", "WAT", 2, Dimer.x[n_Atom_In_Mol], Dimer.y[n_Atom_In_Mol], Dimer.z[n_Atom_In_Mol]);
		fprintf(fWater, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
			n_Atom_In_Mol+2, "H1", "WAT", 2, Dimer.x[n_Atom_In_Mol+1], Dimer.y[n_Atom_In_Mol+1], Dimer.z[n_Atom_In_Mol+1]);
		fprintf(fWater, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
			n_Atom_In_Mol+3, "H2", "WAT", 2, Dimer.x[n_Atom_In_Mol+2], Dimer.y[n_Atom_In_Mol+2], Dimer.z[n_Atom_In_Mol+2]);
		fprintf(fWater, "END \n");
		fclose(fWater);
		
		fprintf(fFile_Run_Log, "mol_H_acceptor.cpp> %2d H acceptor: %2d atom %3s QM, E_min = %7.4lf r_min = %7.4lf\n", 
			AcceptorIdx_List[i]+1, Acceptor_List[i]+1, szElemName[i], E_Min_QM, r_Emin_QM);
		fflush(fFile_Run_Log);


		chdir(szCurDir);
		fEnergy = fopen(szMolWat_E_Int, "a+");
		
		fseek(fEnergy, SEEK_END, 0);
		fprintf(fEnergy, "#Energy    %3d acceptor %2d atom %3s QM ", AcceptorIdx_List[i]+1, Acceptor_List[i]+1, szElemName[Acceptor_List[i]]);
		fprintf(fEnergy, "%12.6lf %9.4lf ", E_Min_QM, r_Emin_QM);
		fprintf(fEnergy, "\n");
		
		fprintf(fEnergy, "Acceptor %5d %12.6lf %9.4lf \n", Acceptor_List[i]+1, E_Min_QM, r_Emin_QM);
		fprintf(fEnergy, "Saved_MM_Parameters %3d %22.16lf %22.16lf\n", 
			Theta_List[i], Para_MM_Save[i][0], Para_MM_Save[i][1]);
		
		fclose(fEnergy);
	}
}


int Is_N_Planar(int Idx, double& x, double& y, double& z)
{
	int i_O, i_A, i_B, i_C;
	double vx_OA, vy_OA, vz_OA;
	double vx_OB, vy_OB, vz_OB;
	double vx_OC, vy_OC, vz_OC;
	double vx_Norm, vy_Norm, vz_Norm, Projection;

	i_O = Idx;
	i_A = BondList[i_O][0];
	i_B = BondList[i_O][1];
	i_C = BondList[i_O][2];

	Neighbor = i_A;

	vx_OA = x_Mol[i_A] - x_Mol[i_O];
	vy_OA = y_Mol[i_A] - y_Mol[i_O];
	vz_OA = z_Mol[i_A] - z_Mol[i_O];
	Normalizex(vx_OA, vy_OA, vz_OA);

	vx_OB = x_Mol[i_B] - x_Mol[i_O];
	vy_OB = y_Mol[i_B] - y_Mol[i_O];
	vz_OB = z_Mol[i_B] - z_Mol[i_O];
	Normalizex(vx_OB, vy_OB, vz_OB);

	vx_OC = x_Mol[i_C] - x_Mol[i_O];
	vy_OC = y_Mol[i_C] - y_Mol[i_O];
	vz_OC = z_Mol[i_C] - z_Mol[i_O];
	Normalizex(vx_OC, vy_OC, vz_OC);

	vx_Norm = vy_OB*vz_OC - vy_OC*vz_OB;
	vy_Norm = vz_OB*vx_OC - vz_OC*vx_OB;
	vz_Norm = vx_OB*vy_OC - vx_OC*vy_OB;
	Normalizex(vx_Norm, vy_Norm, vz_Norm);

	Projection = vx_OA*vx_Norm + vy_OA*vy_Norm + vz_OA*vz_Norm;

	if(fabs(Projection) < 0.25)	{	// planar. Only the direction along Norm.
		return 1;
	}
	else	{
		return 0;
	}
}

int Is_Three_Atoms_Colinear(int ia, int ib, int ic)
{
	double v1_x, v1_y, v1_z;
	double v2_x, v2_y, v2_z;
	double dot_v1_v2;

	v1_x = x_Mol[ib] - x_Mol[ia];
	v1_y = y_Mol[ib] - y_Mol[ia];
	v1_z = z_Mol[ib] - z_Mol[ia];

	v2_x = x_Mol[ic] - x_Mol[ib];
	v2_y = y_Mol[ic] - y_Mol[ib];
	v2_z = z_Mol[ic] - z_Mol[ib];

	Normalizex(v1_x, v1_y, v1_z);
	Normalizex(v2_x, v2_y, v2_z);

	dot_v1_v2 = fabs(Dot_Product(v1_x, v1_y, v1_z, v2_x, v2_y, v2_z));
	if(dot_v1_v2 > cos(15.0*radianInv))	{	// smaller than 10 degree
		return 1;
	}
	else	{
		return 0;
	}
}

void Generate_Dummy_Atoms_Bond_1(int Idx)
{
	int i, i_O, i_A, v_Aux_Sel, Is_Colinear;
	double v_Aux[2][3]={{1, 1, 0}, {0, 1, 1}}, dot_1, dot_2;
	double v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2;

	i_O = Idx;
	i_A = BondList[i_O][0];
	Neighbor = i_A;

	x_Dummy_1 = x_Mol[i_A];	// dummy atom 1
	y_Dummy_1 = y_Mol[i_A];	// dummy atom 1
	z_Dummy_1 = z_Mol[i_A];	// dummy atom 1

	v_x_X1_Acceptor = x_Mol[i_O] - x_Mol[i_A];
	v_y_X1_Acceptor = y_Mol[i_O] - y_Mol[i_A];
	v_z_X1_Acceptor = z_Mol[i_O] - z_Mol[i_A];
	Normalizex(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor);
	
	if(Mol.nAtom == 2)	{
		dot_1 = fabs(Dot_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, v_Aux[0][0], v_Aux[0][1], v_Aux[0][2]));
		dot_2 = fabs(Dot_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, v_Aux[1][0], v_Aux[1][1], v_Aux[1][2]));
		
		if(dot_1 <= dot_2)	{
			v_Aux_Sel = 0;
		}
		else	{
			v_Aux_Sel = 1;
		}
		
		Cross_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, v_Aux[v_Aux_Sel][0], v_Aux[v_Aux_Sel][1], v_Aux[v_Aux_Sel][2], v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2);
	}
	else	{
		if(Bond_Count[i_A] == 0)	{
			GetBondList(i_A);
		}
		for(i=0; i<Bond_Count[i_A]; i++)	{
			if(BondList[i_A][i] != Idx)	{	// 2nd neighbor atom
				break;
			}
		}
		if(i >= Bond_Count[i_A])	{
			Quit_With_Error_Msg("Donor> Error in Generate_Dummy_Atoms_Bond_1().\nQuit\n");
		}
		i = BondList[i_A][i];

		//start	to check whether three atoms (Idx, i_A, i) are colinear or not
		Is_Colinear = Is_Three_Atoms_Colinear(i_O, i_A, i);
		if(Is_Colinear)	{
			dot_1 = fabs(Dot_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, v_Aux[0][0], v_Aux[0][1], v_Aux[0][2]));
			dot_2 = fabs(Dot_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, v_Aux[1][0], v_Aux[1][1], v_Aux[1][2]));
			
			if(dot_1 <= dot_2)	{
				v_Aux_Sel = 0;
			}
			else	{
				v_Aux_Sel = 1;
			}
			
			Cross_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, v_Aux[v_Aux_Sel][0], v_Aux[v_Aux_Sel][1], v_Aux[v_Aux_Sel][2], v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2);
		}
		else	{
			Cross_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, x_Mol[i_A]-x_Mol[i], y_Mol[i_A]-y_Mol[i], z_Mol[i_A]-z_Mol[i], v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2);
		}
		//end	to check whether three atoms (Idx, i_A, i) are colinear or not
	}

	Normalizex(v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2);
	
	x_Dummy_2 = x_Mol[i_O] + R_DUMMY_2 * v_x_Acceptor_X2;
	y_Dummy_2 = y_Mol[i_O] + R_DUMMY_2 * v_y_Acceptor_X2;
	z_Dummy_2 = z_Mol[i_O] + R_DUMMY_2 * v_z_Acceptor_X2;
}

void Generate_Dummy_Atoms_Bond_2(int Idx)
{
	int i_O, i_A, i_B;
	double vx_Acceptor_A, vy_Acceptor_A, vz_Acceptor_A, vx_Acceptor_B, vy_Acceptor_B, vz_Acceptor_B;
	double v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2;

	i_O = Idx;
	i_A = BondList[i_O][0];
	i_B = BondList[i_O][1];
	Neighbor = i_A;

	vx_Acceptor_A = x_Mol[i_A] - x_Mol[i_O];
	vy_Acceptor_A = y_Mol[i_A] - y_Mol[i_O];
	vz_Acceptor_A = z_Mol[i_A] - z_Mol[i_O];
	Normalizex(vx_Acceptor_A, vy_Acceptor_A, vz_Acceptor_A);

	vx_Acceptor_B = x_Mol[i_B] - x_Mol[i_O];
	vy_Acceptor_B = y_Mol[i_B] - y_Mol[i_O];
	vz_Acceptor_B = z_Mol[i_B] - z_Mol[i_O];
	Normalizex(vx_Acceptor_B, vy_Acceptor_B, vz_Acceptor_B);

	v_x_X1_Acceptor = -(vx_Acceptor_A + vx_Acceptor_B);
	v_y_X1_Acceptor = -(vy_Acceptor_A + vy_Acceptor_B);
	v_z_X1_Acceptor = -(vz_Acceptor_A + vz_Acceptor_B);
	Normalizex(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor);

	x_Dummy_1 = x_Mol[i_O] - R_DUMMY_1 * v_x_X1_Acceptor;
	y_Dummy_1 = y_Mol[i_O] - R_DUMMY_1 * v_y_X1_Acceptor;
	z_Dummy_1 = z_Mol[i_O] - R_DUMMY_1 * v_z_X1_Acceptor;

	Cross_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, vx_Acceptor_A, vy_Acceptor_A, vz_Acceptor_A, v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2);
	Normalizex(v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2);

	x_Dummy_2 = x_Mol[i_O] + R_DUMMY_2 * v_x_Acceptor_X2;
	y_Dummy_2 = y_Mol[i_O] + R_DUMMY_2 * v_y_Acceptor_X2;
	z_Dummy_2 = z_Mol[i_O] + R_DUMMY_2 * v_z_Acceptor_X2;
}

void Rotate_Dummy_Atoms(int Idx, double theta)
{
	double v1_New_x, v1_New_y, v1_New_z;
	double v2_x, v2_y, v2_z, v2_New_x, v2_New_y, v2_New_z;
	double v3_x, v3_y, v3_z;
//	double v3_New_x, v3_New_y, v3_New_z;
	double RotM[3][3], cos_theta, sin_theta;

	theta *= radianInv;
	cos_theta = cos(theta);
	sin_theta = sin(theta);

	v_x_X1_Acceptor = x_Mol[Idx] - x_Dummy_1_Org;	// X vector
	v_y_X1_Acceptor = y_Mol[Idx] - y_Dummy_1_Org;
	v_z_X1_Acceptor = z_Mol[Idx] - z_Dummy_1_Org;
	Normalizex(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor);

	v2_x = x_Mol[Idx] - x_Dummy_2_Org;
	v2_y = y_Mol[Idx] - y_Dummy_2_Org;
	v2_z = z_Mol[Idx] - z_Dummy_2_Org;
	Normalizex(v2_x, v2_y, v2_z);

//	FILE *fOut;
//	fOut = fopen("ini.pdb", "w");
//	fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 1, "O", "Mol", 1, x_Mol[Idx], y_Mol[Idx], z_Mol[Idx]);
//	fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 1, "O", "Mol", 2, x_Mol[Idx]-R_DUMMY_1*v_x_X1_Acceptor, y_Mol[Idx]-R_DUMMY_1*v_y_X1_Acceptor, z_Mol[Idx]-R_DUMMY_1*v_z_X1_Acceptor);
//	fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 1, "O", "Mol", 3, x_Mol[Idx]-R_DUMMY_2*v2_x, y_Mol[Idx]-R_DUMMY_2*v2_y, z_Mol[Idx]-R_DUMMY_2*v2_z);
//	fclose(fOut);

	Cross_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, v2_x, v2_y, v2_z, v3_x, v3_y, v3_z);

	Normalizex(v3_x, v3_y, v3_z);

	RotM[0][0] = v3_x*v3_x + (1-v3_x*v3_x)*cos_theta;
	RotM[0][1] = v3_x*v3_y*(1.0-cos_theta) - v3_z*sin_theta;
	RotM[0][2] = v3_x*v3_z*(1.0-cos_theta) + v3_y*sin_theta;
	
	RotM[1][0] = v3_x*v3_y*(1.0-cos_theta) + v3_z*sin_theta;
	RotM[1][1] = v3_y*v3_y + (1-v3_y*v3_y)*cos_theta;
	RotM[1][2] = v3_y*v3_z*(1.0-cos_theta) - v3_x*sin_theta;
	
	RotM[2][0] = v3_x*v3_z*(1.0-cos_theta) - v3_y*sin_theta;
	RotM[2][1] = v3_y*v3_z*(1.0-cos_theta) + v3_x*sin_theta;
	RotM[2][2] = v3_z*v3_z + (1-v3_z*v3_z)*cos_theta;


	v1_New_x = RotM[0][0] * v_x_X1_Acceptor + RotM[0][1] * v_y_X1_Acceptor + RotM[0][2] * v_z_X1_Acceptor;
	v1_New_y = RotM[1][0] * v_x_X1_Acceptor + RotM[1][1] * v_y_X1_Acceptor + RotM[1][2] * v_z_X1_Acceptor;
	v1_New_z = RotM[2][0] * v_x_X1_Acceptor + RotM[2][1] * v_y_X1_Acceptor + RotM[2][2] * v_z_X1_Acceptor;

	v2_New_x = RotM[0][0] * v2_x + RotM[0][1] * v2_y + RotM[0][2] * v2_z;
	v2_New_y = RotM[1][0] * v2_x + RotM[1][1] * v2_y + RotM[1][2] * v2_z;
	v2_New_z = RotM[2][0] * v2_x + RotM[2][1] * v2_y + RotM[2][2] * v2_z;

//	v3_New_x = RotM[0][0] * v3_x + RotM[0][1] * v3_y + RotM[0][2] * v3_z;	// not changed
//	v3_New_y = RotM[1][0] * v3_x + RotM[1][1] * v3_y + RotM[1][2] * v3_z;	// not changed
//	v3_New_z = RotM[2][0] * v3_x + RotM[2][1] * v3_y + RotM[2][2] * v3_z;	// not changed

//	fOut = fopen("end.pdb", "w");
//	fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 1, "O", "Mol", 1, x_Mol[Idx], y_Mol[Idx], z_Mol[Idx]);
//	fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 1, "O", "Mol", 2, x_Mol[Idx]-R_DUMMY_1*v1_New_x, y_Mol[Idx]-R_DUMMY_1*v1_New_y, z_Mol[Idx]-R_DUMMY_1*v1_New_z);
//	fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 1, "O", "Mol", 3, x_Mol[Idx]-R_DUMMY_2*v2_New_x, y_Mol[Idx]-R_DUMMY_2*v2_New_y, z_Mol[Idx]-R_DUMMY_2*v2_New_z);
//	fclose(fOut);

	x_Dummy_1 = x_Mol[Idx] - R_DUMMY_1*v1_New_x;
	y_Dummy_1 = y_Mol[Idx] - R_DUMMY_1*v1_New_y;
	z_Dummy_1 = z_Mol[Idx] - R_DUMMY_1*v1_New_z;

	x_Dummy_2 = x_Mol[Idx] - R_DUMMY_2*v2_New_x;
	y_Dummy_2 = y_Mol[Idx] - R_DUMMY_2*v2_New_y;
	z_Dummy_2 = z_Mol[Idx] - R_DUMMY_2*v2_New_z;

	v_x_X1_Acceptor = v1_New_x;
	v_y_X1_Acceptor = v1_New_y;
	v_z_X1_Acceptor = v1_New_z;
}

void Generate_Dummy_Atoms_Bond_Perp(int Idx)
{
	double xTmp, yTmp, zTmp;

	xTmp = x_Dummy_1;			yTmp = y_Dummy_1;			zTmp = z_Dummy_1;
	x_Dummy_1 = x_Dummy_2;		y_Dummy_1 = y_Dummy_2;		z_Dummy_1 = z_Dummy_2;
	x_Dummy_2 = xTmp;			y_Dummy_2 = yTmp;			z_Dummy_2 = zTmp;

	v_x_X1_Acceptor = x_Mol[Idx] - x_Dummy_1;
	v_y_X1_Acceptor = y_Mol[Idx] - y_Dummy_1;
	v_z_X1_Acceptor = z_Mol[Idx] - z_Dummy_1;
	Normalizex(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor);
}

void Generate_Dummy_Atoms_Bond_Perp_Flipped(int Idx)
{
	v_x_X1_Acceptor = -v_x_X1_Acceptor;
	v_y_X1_Acceptor = -v_y_X1_Acceptor;
	v_z_X1_Acceptor = -v_z_X1_Acceptor;

	x_Dummy_1 = x_Mol[Idx] - R_DUMMY_1 * v_x_X1_Acceptor;
	y_Dummy_1 = y_Mol[Idx] - R_DUMMY_1 * v_y_X1_Acceptor;
	z_Dummy_1 = z_Mol[Idx] - R_DUMMY_1 * v_z_X1_Acceptor;
}

void Generate_Dummy_Atoms_Bond_3(int Idx)
{
	int i_O, i_A, i_B, i_C;
	double vx_Acceptor_A, vy_Acceptor_A, vz_Acceptor_A, vx_Acceptor_B, vy_Acceptor_B, vz_Acceptor_B, vx_Acceptor_C, vy_Acceptor_C, vz_Acceptor_C;
	double v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2;

	i_O = Idx;
	i_A = BondList[i_O][0];
	i_B = BondList[i_O][1];
	i_C = BondList[i_O][2];
	Neighbor = i_A;

	vx_Acceptor_A = x_Mol[i_A] - x_Mol[i_O];
	vy_Acceptor_A = y_Mol[i_A] - y_Mol[i_O];
	vz_Acceptor_A = z_Mol[i_A] - z_Mol[i_O];
	Normalizex(vx_Acceptor_A, vy_Acceptor_A, vz_Acceptor_A);

	vx_Acceptor_B = x_Mol[i_B] - x_Mol[i_O];
	vy_Acceptor_B = y_Mol[i_B] - y_Mol[i_O];
	vz_Acceptor_B = z_Mol[i_B] - z_Mol[i_O];
	Normalizex(vx_Acceptor_B, vy_Acceptor_B, vz_Acceptor_B);

	vx_Acceptor_C = x_Mol[i_C] - x_Mol[i_O];
	vy_Acceptor_C = y_Mol[i_C] - y_Mol[i_O];
	vz_Acceptor_C = z_Mol[i_C] - z_Mol[i_O];
	Normalizex(vx_Acceptor_C, vy_Acceptor_C, vz_Acceptor_C);

	v_x_X1_Acceptor = -(vx_Acceptor_A + vx_Acceptor_B + vx_Acceptor_C);
	v_y_X1_Acceptor = -(vy_Acceptor_A + vy_Acceptor_B + vy_Acceptor_C);
	v_z_X1_Acceptor = -(vz_Acceptor_A + vz_Acceptor_B + vz_Acceptor_C);
	Normalizex(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor);

	x_Dummy_1 = x_Mol[i_O] - R_DUMMY_1 * v_x_X1_Acceptor;
	y_Dummy_1 = y_Mol[i_O] - R_DUMMY_1 * v_y_X1_Acceptor;
	z_Dummy_1 = z_Mol[i_O] - R_DUMMY_1 * v_z_X1_Acceptor;

	Cross_Product(v_x_X1_Acceptor, v_y_X1_Acceptor, v_z_X1_Acceptor, vx_Acceptor_A, vy_Acceptor_A, vz_Acceptor_A, v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2);
	Normalizex(v_x_Acceptor_X2, v_y_Acceptor_X2, v_z_Acceptor_X2);

	x_Dummy_2 = x_Mol[i_O] + R_DUMMY_2 * v_x_Acceptor_X2;
	y_Dummy_2 = y_Mol[i_O] + R_DUMMY_2 * v_y_Acceptor_X2;
	z_Dummy_2 = z_Mol[i_O] + R_DUMMY_2 * v_z_Acceptor_X2;
}


void Make_List_H_Acceptor(void)
{
	FILE *fIn;
	int i;
	char ErrorMsg[256];

	fIn = fopen(szFileElem, "r");
	if(fIn == NULL)	{
		sprintf(ErrorMsg, "Fail to open file %s\nQuit\n", szFileElem);
		Quit_With_Error_Msg(ErrorMsg);
	}

	memset(Is_N, 0, sizeof(int)*n_Atom_In_Mol);
	memset(Is_O, 0, sizeof(int)*n_Atom_In_Mol);
	memset(Is_F, 0, sizeof(int)*n_Atom_In_Mol);
	memset(Is_S, 0, sizeof(int)*n_Atom_In_Mol);

	for(i=0; i<n_Atom_In_Mol; i++)	{
		fscanf(fIn, "%s", szElemName[i]);
	}
	fclose(fIn);

	for(i=0; i<n_Atom_In_Mol; i++)	{
		if(strcmp(szElemName[i], "N")==0)	{
			Is_N[i] = 1;
			GetBondList(i);
		}
		else if(strcmp(szElemName[i], "O")==0)	{
			Is_O[i] = 1;
			GetBondList(i);
		}
		else if(strcmp(szElemName[i], "F")==0 || strcmp(szElemName[i], "Cl")==0 || strcmp(szElemName[i], "CL")==0 || strcmp(szElemName[i], "Br")==0 || strcmp(szElemName[i], "BR")==0 || strcmp(szElemName[i], "I")==0 )	{ // we use F for all allogen 
			Is_F[i] = 1;
			GetBondList(i);
		}
		else if(strcmp(szElemName[i], "S")==0)	{
			Is_S[i] = 1;
			GetBondList(i);
		}
	}
}

void GetBondList(int Idx)
{
	int i, nBond, iPos, *pBondList;

	nBond = Mol.nBond;
	pBondList = Mol.BondList;

	Bond_Count[Idx] = 0;
	for(i=0; i<nBond; i++)	{
		iPos = 2*i;
		if(pBondList[iPos] == Idx)	{
			BondList[Idx][Bond_Count[Idx]] = pBondList[iPos+1];
			Bond_Count[Idx]++;
		}
		if(pBondList[iPos+1] == Idx)	{
			BondList[Idx][Bond_Count[Idx]] = pBondList[iPos];
			Bond_Count[Idx]++;
		}
	}
	return;
}


void Output_Optimize_Water_Pose_QM(void)
{
	FILE *fOut;
	int i;
	char szName_Result[256]="opt-output.out", szAcceptor[256];

	//start	to generate the Gaussian script for optimization with ModRedundant
	fOut = fopen(szName_Gaussian, "w");
	fprintf(fOut, "%s", szQM_Level_Int_E_Dimer_Opt_Cmd);
	sprintf(szAcceptor, "%s99", szElemName[ActiveAtom]);	// make up a name for this atom
	for(i=0; i<n_Atom_In_Mol; i++)	{
		if(i==ActiveAtom)	{
			fprintf(fOut, "%s  %10.5lf%10.5lf%10.5lf\n", szAcceptor, x_ReadIn[i], y_ReadIn[i], z_ReadIn[i]);
		}
		else	{
			fprintf(fOut, "%s    %10.5lf%10.5lf%10.5lf\n", szElemName[i], x_ReadIn[i], y_ReadIn[i], z_ReadIn[i]);
		}
	}
	fprintf(fOut, "%s   %10.5lf%10.5lf%10.5lf\n", "X1", x_Dummy_1, y_Dummy_1, z_Dummy_1);
	fprintf(fOut, "%s   %10.5lf%10.5lf%10.5lf\n", "X2", x_Dummy_2, y_Dummy_2, z_Dummy_2);

	fprintf(fOut, "H1W  %s  roh X2 90.0 X1 180.0 \n", szAcceptor);

	fprintf(fOut, "X3   H1W  %10.4lf %s  90.0 X2   0.0 \n", R_DUMMY_2, szAcceptor);
	fprintf(fOut, "O1W   H1W  %10.4lf X3  90.0 X2 180.0 \n", b0_H_O_HF);
	fprintf(fOut, "H2W   O1W  %10.4lf H1W %10.4lf X3  phi \n", b0_H_O_HF, theta0_H_O_H_HF);

	fprintf(fOut, "\nroh %10.4lf\nphi %lf\n", Para_Save_for_QM[0]+0.15, Para_Save_for_QM[1]*radian);	//shifted distance
	
	fclose(fOut);
	//end	to generate the Gaussian script for optimization with ModRedundant


	strcpy(szInputList[nJob], szName_Gaussian);
	sprintf(szOutputList[nJob], "%s/%s", szDirList[nJob], szName_Result);

	return;
}


double Optimize_Water_Pose(void)
{
	nlopt_opt opt;

	Low_Bound[0] = 1.6;
	Up_Bound[0] = 2.8;
	Low_Bound[1] = -10.0;
	Up_Bound[1] = 10.0;

	opt = nlopt_create(NLOPT_LD_LBFGS, N_PARA); /* algorithm and dimensionality */
//	opt = nlopt_create(NLOPT_LD_LBFGS_NOCEDAL, N_PARA); /* algorithm and dimensionality */
	nlopt_set_lower_bounds(opt, Low_Bound);
	nlopt_set_upper_bounds(opt, Up_Bound);
	nlopt_set_min_objective(opt, Callback_Eval_Gradient, NULL);
	nlopt_set_xtol_rel(opt, 1.0E-5);

	E_Min=1.0E20;
	CalObjectiveFunction();
//	printf("Iteration %4d  E = %10.5lf\n", Iteration, E_Dimer_Int);

	FailCount = 0;
	Iteration = 0;

	memcpy(Para_Best, Para_List, sizeof(double)*N_PARA);
	if (nlopt_optimize(opt, Para_List, &E_Dimer_Min) < 0) {
		printf("While optimizing water pose: nlopt failed!\n");
	}
	else {
		printf("Optimization of water pose: Obj_Min = %16.10lf\n", E_Dimer_Min);
	}

	nlopt_destroy(opt);

	if(Para_Best[1] < -PI2)	{
		Para_Best[1] += PI2;
	}
	else if(Para_Best[1] > PI2)	{
		Para_Best[1] -= PI2;
	}

	memcpy(Para_List, Para_Best, sizeof(double)*N_PARA);
	E_Dimer_Min = CalObjectiveFunction();


	return E_Dimer_Min;
}

double Callback_Eval_Gradient(unsigned n, const double *x, double *grad, void *my_func_data)
{
	int i, n_Local;
//	char szCmd[256];
//	FILE *fOut;

	n_Local = (int)n;
	for(i=0; i<n_Local; i++)	{
		Para_List[i] = x[i];
	}

	if(grad)	{
		CalGradient();	//gradient will be assigned into objGrad automatically
		Iteration++;
		for(i=0; i<n_Local; i++)	{
			grad[i] = Grad_List[i];
		}
//		printf("Iteration %4d  E = %16.8lf\n", Iteration, E_Dimer_Int);

		if(E_Dimer_Int < E_Min)	{
			E_Min = E_Dimer_Int;
			FailCount = 0;

			memcpy(Para_Best, x, sizeof(double)*n);
//			sprintf(szCmd, "cp %s opt.gjf", szName_Gaussian);
//			system(szCmd);
//			fOut = fopen("E_min.txt", "w");
//			fprintf(fOut, "%20.12lf\n%20.12lf\n%20.12lf\n%20.12lf\n", Para_List[0], Para_List[1], Para_List[2], Para_List[3]);
//			fprintf(fOut, "E = %15.8lf\n", E_Min);
//			fclose(fOut);
		}
		else	{
			if(FailCount > 10)      {       // cannot converge due to limited accuracy of numerical gradient
				printf("Too much failed tries.\nI have tried my best.\nQuit.\n");
//				printf("E_Min = %12.6lf\n", E_Min);
//				exit(0);
				memset(grad, 0, sizeof(double)*n);
			}
			FailCount++;
		}
	}
	else	{	// cal object function only
		CalObjectiveFunction();
	}

    return E_Dimer_Int;
}

double CalObjectiveFunction(void)	// only used for the optimization in MM
{
	GenerateWater();
//	Generate_Gaussian_Input();
	E_Dimer_Int = Dimer.Cal_E_Int();

	return E_Dimer_Int;
}

double Get_E_Mol_Water_Far_QM()
{
	FILE *fOut, *fIn;
	char szFileEnergy[]="energy_sum.txt";
	int i, ReadItem;
	char szCmd[256], szName_Result[256]="cale-output.out", szName_Gaussian_Single_Mol[]="single-mol.gjf", szName_Gaussian_water[]="single-wat.gjf";
	char szResult_Single_Mol[]="output-single-mol.out", szResult_Single_Wat[]="output-single-wat.out";
	double E_Mol, E_Water, E_Mol_Water;

	fIn = fopen(szFileEnergy, "r");
	if(fIn != NULL)	{
		ReadItem = fscanf(fIn, "%lf", &E_Mol_Water);
		fclose(fIn);
		if(ReadItem == 1)	{
			return E_Mol_Water;
		}
	}


	fOut = fopen(szName_Gaussian_Single_Mol, "w");
	fprintf(fOut, "%s", szQM_Level_Int_E_Single_Mol_Cmd);
	for(i=0; i<n_Atom_In_Mol; i++)	{
		fprintf(fOut, "%s  %10.5lf%10.5lf%10.5lf\n", szElemName[i], x_ReadIn[i], y_ReadIn[i], z_ReadIn[i]);
	}
	fprintf(fOut, "\n\n");
	fclose(fOut);
	sprintf(szCmd, "%s < %s > %s", szExe_G09, szName_Gaussian_Single_Mol, szResult_Single_Mol);
	system(szCmd);
	E_Mol = Extract_E_Gaussian_Output(szResult_Single_Mol, " SCF Done:");

	fOut = fopen(szName_Gaussian_water, "w");
	fprintf(fOut, "%s", szQM_Level_Int_E_Single_Wat_Cmd);
	fprintf(fOut, "O  %10.5lf%10.5lf%10.5lf\n", 0.0, 0.0, 0.0);
	fprintf(fOut, "H  %10.5lf%10.5lf%10.5lf\n", b0_H_O_HF, 0.0, 0.0);
	fprintf(fOut, "H  %10.5lf%10.5lf%10.5lf\n\n", b0_H_O_HF*cos(theta0_H_O_H_HF*radianInv), b0_H_O_HF*sin(theta0_H_O_H_HF*radianInv), 0.0);
	fprintf(fOut, "\n\n");
	fclose(fOut);
	sprintf(szCmd, "%s < %s > %s", szExe_G09, szName_Gaussian_water, szResult_Single_Wat);
	system(szCmd);
	E_Water = Extract_E_Gaussian_Output(szResult_Single_Wat, " SCF Done:");
	
	fOut = fopen(szFileEnergy, "w");
	fprintf(fOut, "%18.14E\n", E_Mol+E_Water);
	fclose(fOut);

	return (E_Mol+E_Water);
}

void Replace_D_E(char szStr[])
{
	int nLen, i;

	nLen = strlen(szStr);
	for(i=0; i<nLen; i++)	{
		if(szStr[i] == 'D')	{
			szStr[i] = 'E';
			return;
		}
	}
	return;
}


double Extract_E_Gaussian_Output(char szFileName[], char szTag[])
{
	FILE *fIn;
	char *ReadLine, szLine[256], szStr_Energy[256], ErrorMsg[256];
	int ReadItem;
	double E_Dimer;

	fIn = fopen(szFileName, "r");
	if(FindString(szTag, "SCF Done:")>=0)	{
		while(1)	{
			if(feof(fIn))	{
				break;
			}
			ReadLine = fgets(szLine, 256, fIn);
			if(ReadLine)	{
				if(FindString(szLine, " SCF Done:  E(RHF)") >= 0)	{
					ReadItem = sscanf(szLine+20, "%s", szStr_Energy);
					Replace_D_E(szStr_Energy);
					ReadItem = sscanf(szStr_Energy, "%lf", &E_Dimer);
					if(ReadItem == 1)	{
						fclose(fIn);
						return E_Dimer;
					}
				}
			}
		}
	}
	else if(FindString(szTag, "Counterpoise: corrected energy =")>=0)	{
		while(1)	{
			if(feof(fIn))	{
				break;
			}
			ReadLine = fgets(szLine, 256, fIn);
			if(ReadLine)	{
				if(FindString(szLine, "Counterpoise: corrected energy =") >= 0)	{
					ReadItem = sscanf(szLine+33, "%s", szStr_Energy);
					Replace_D_E(szStr_Energy);
					ReadItem = sscanf(szStr_Energy, "%lf", &E_Dimer);
					if(ReadItem == 1)	{
						fclose(fIn);
						return E_Dimer;
					}
				}
			}
		}
	}
	else if(FindString(szTag, "MM energy: ")>=0)	{
		while(1)	{
			if(feof(fIn))	{
				break;
			}
			ReadLine = fgets(szLine, 256, fIn);
			if(ReadLine)	{
				if(FindString(szLine, "MM energy: ") >= 0)	{
					ReadItem = sscanf(szLine+11, "%s", szStr_Energy);
					Replace_D_E(szStr_Energy);
					ReadItem = sscanf(szStr_Energy, "%lf", &E_Dimer);
					if(ReadItem == 1)	{
						fclose(fIn);
						return E_Dimer;
					}
				}
			}
		}
	}
	else	{
		sprintf(ErrorMsg, "Extract_E_Gaussian_Output> Unsupported tags for extracting energies from Gaussian output. %s\nQuit\n", szTag);
		fflush(fFile_Run_Log);
		fclose(fIn);
		Quit_With_Error_Msg(ErrorMsg);
	}
	return 0.0;
}

#define DELTA_PARA	(2.0E-4)
//#define DELTA_PARA	(5.0E-3)
double CalGradient(void)
{
	int i;
	double Para_Save[N_PARA];
	double f_Left, f_Right;
	
	for(i=0; i<N_PARA; i++)	{
		Para_Save[i] = Para_List[i];	//save current parameters
	}

	for(i=0; i<N_PARA; i++)	{
		Para_List[i] = Para_Save[i] - DELTA_PARA;
		f_Left = CalObjectiveFunction();
		
		Para_List[i] = Para_Save[i] + DELTA_PARA;
		f_Right = CalObjectiveFunction();
		
		Grad_List[i] = (f_Right-f_Left)/(2.0*DELTA_PARA);
//		printf("%10.5lf\n", Grad_List[i]);
		
		Para_List[i] = Para_Save[i];	//restore save (correct) parameter
	}
	
	CalObjectiveFunction();

	return E_Dimer_Int;
}

#undef DELTA_PARA

void ReadMolCRD(void)
{
	FILE *fIn;
	int ReadItem, i;
	char szLine[256], *ReadLine, ErrorMsg[256];


	fIn = fopen(szNameMolCRD, "r");
	if(fIn == NULL)	{
		sprintf(ErrorMsg, "Fail to open file %s.\nQuit\n", szNameMolCRD);
		Quit_With_Error_Msg(ErrorMsg);
	}

	while(1)	{
		if(feof(fIn))	{
			sprintf(ErrorMsg, "Error to find the line which contains the number of atoms.\nQuit.\n");
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}
		fgets(szLine, 256, fIn);
		ReadItem = sscanf(szLine, "%d", &n_Atom_In_Mol);
		if(ReadItem == 1)	{
			break;
		}
	}

	for(i=0; i<n_Atom_In_Mol; i++)	{
		if(feof(fIn))	{
			sprintf(ErrorMsg, "Error in reading the coodinates of Mol.\nFile is not complete. \nQuit.\n");
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			sprintf(ErrorMsg, "Error in reading the coodinates of Mol.\nFile is not complete. \nQuit.\n");
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}

		ReadItem = sscanf(szLine+6, "%d", &(ResIDMol[i]));
		ReadItem = sscanf(szLine+11, "%s %s", szResNameMol[i], szAtomNameMol[i]);
		ReadItem = sscanf(szLine+20, "%lf%lf%lf", &(x_Mol[i]), &(y_Mol[i]), &(z_Mol[i]));
		if(ReadItem != 3)	{
			sprintf(ErrorMsg, "Error in reading the coodinates of Mol.\nFile is not complete. \nQuit.\n");
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}
	}

	fclose(fIn);
}

void Gen_xyz(double x_A, double y_A, double z_A, 
			 double x_B, double y_B, double z_B, 
			 double x_C, double y_C, double z_C, 
			 double r, double theta, double phi, 
			 double& x_D, double& y_D, double& z_D)
{
	double vz_x, vz_y, vz_z, BA_x, BA_y, BA_z;
	double vy_x, vy_y, vy_z, vx_x, vx_y, vx_z;
	double cos_phi, sin_phi, cos_theta, sin_theta;
	double r_x, r_y, r_z;

	cos_phi = cos(phi);
	sin_phi = sin(phi);

	vz_x = x_C - x_B;
	vz_y = y_C - y_B;
	vz_z = z_C - z_B;
	Normalizex(vz_x, vz_y, vz_z);	

	BA_x = x_A - x_B;
	BA_y = y_A - y_B;
	BA_z = z_A - z_B;
	Normalizex(BA_x, BA_y, BA_z);	

	vy_x = vz_y*BA_z - vz_z*BA_y;
	vy_y = vz_z*BA_x - vz_x*BA_z;
	vy_z = vz_x*BA_y - vz_y*BA_x;
	Normalizex(vy_x, vy_y, vy_z);

	vx_x = vy_y*vz_z - vy_z*vz_y;
	vx_y = vy_z*vz_x - vy_x*vz_z;
	vx_z = vy_x*vz_y - vy_y*vz_x;

	cos_theta = cos(PI-theta);
	sin_theta = sin(PI-theta);
	
	r_z = r*cos_theta;
	r_x = r*sin_theta*cos_phi;
	r_y = r*sin_theta*sin_phi;
	
	x_D = x_C + vx_x*r_x + vy_x*r_y + vz_x*r_z;
	y_D = y_C + vx_y*r_x + vy_y*r_y + vz_y*r_z;
	z_D = z_C + vx_z*r_x + vy_z*r_y + vz_z*r_z;

	return;
}


void GenerateWater(void)	// with six degree of freedom for water molecule
{
	double r;

	r = Para_List[0];
	H1_Wat_x = x_Mol[ActiveAtom] + r*v_x_X1_Acceptor;
	H1_Wat_y = y_Mol[ActiveAtom] + r*v_y_X1_Acceptor;
	H1_Wat_z = z_Mol[ActiveAtom] + r*v_z_X1_Acceptor;

	x_Dummy_3 = H1_Wat_x + (x_Dummy_2 - x_Mol[ActiveAtom]);
	y_Dummy_3 = H1_Wat_y + (y_Dummy_2 - y_Mol[ActiveAtom]);
	z_Dummy_3 = H1_Wat_z + (z_Dummy_2 - z_Mol[ActiveAtom]);

	Gen_xyz(x_Dummy_2, y_Dummy_2, z_Dummy_2, x_Dummy_3, y_Dummy_3, z_Dummy_3, 
		H1_Wat_x, H1_Wat_y, H1_Wat_z, b0_H_O_EXP, PI*0.5, PI, O_Wat_x, O_Wat_y, O_Wat_z);

	Gen_xyz(x_Dummy_3, y_Dummy_3, z_Dummy_3, H1_Wat_x, H1_Wat_y, H1_Wat_z, 
		O_Wat_x, O_Wat_y, O_Wat_z, b0_H_O_EXP, theta0_H_O_H_EXP*radianInv, Para_List[1], H2_Wat_x, H2_Wat_y, H2_Wat_z);

	Dimer.x[Idx_O_Wat] = O_Wat_x;	Dimer.y[Idx_O_Wat] = O_Wat_y;	Dimer.z[Idx_O_Wat] = O_Wat_z;
	Dimer.x[Idx_H1_Wat] = H1_Wat_x;	Dimer.y[Idx_H1_Wat] = H1_Wat_y;	Dimer.z[Idx_H1_Wat] = H1_Wat_z;
	Dimer.x[Idx_H2_Wat] = H2_Wat_x;	Dimer.y[Idx_H2_Wat] = H2_Wat_y;	Dimer.z[Idx_H2_Wat] = H2_Wat_z;
}

inline double Dot_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b)
{
	return (x_a*x_b + y_a*y_b + z_a*z_b);
}

inline void Cross_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b, double& x_Product, double& y_Product, double& z_Product)
{
	x_Product = y_a*z_b - y_b*z_a;
	y_Product = z_a*x_b - z_b*x_a;
	z_Product = x_a*y_b - x_b*y_a;
}

double Normalizex(double& vect_x, double& vect_y, double& vect_z)
{
	double dist, dist_Inv;

	dist = sqrt(vect_x*vect_x + vect_y*vect_y + vect_z*vect_z);
	if(dist < 1.0E-100)	{
		printf("");
	}
	dist_Inv = 1.0/dist;
	vect_x *= dist_Inv;
	vect_y *= dist_Inv;
	vect_z *= dist_Inv;
	return dist;
}

void OutputCRD(void)
{
	FILE *fOut;
	int i, ResBase, Water_Count=0, nAtom;

	fOut = fopen("solvated-mol.crd", "w");
	for(i=0; i<n_Atom_In_Mol; i++)	{
		fprintf(fOut, "%5d%5d %-5s%-4s%10.5lf%10.5lf%10.5lf %-4s %-5d  0.00000\n", 
			i+1, ResIDMol[i], szResNameMol[i], szAtomNameMol[i], x_Mol[i], y_Mol[i], z_Mol[i], szResNameMol[i], ResIDMol[i]);
	}
	ResBase = ResIDMol[n_Atom_In_Mol-1]+1;
	nAtom = n_Atom_In_Mol;



	for(Water_Count=0; Water_Count<6; Water_Count++)	{
//		GenerateWater(H1_Wat_x, H1_Wat_y, H1_Wat_z, 60.0*Water_Count);
		GenerateWater();

		fprintf(fOut, "%5d%5d SWM4 OH2 %10.5lf%10.5lf%10.5lf WAT  %-5d  0.00000\n", 
			nAtom+1, ResBase, O_Wat_x, O_Wat_y, O_Wat_z, Water_Count+1);
		fprintf(fOut, "%5d%5d SWM4 H1  %10.5lf%10.5lf%10.5lf WAT  %-5d  0.00000\n", 
			nAtom+2, ResBase, H1_Wat_x, H1_Wat_y, H1_Wat_z, Water_Count+1);
		fprintf(fOut, "%5d%5d SWM4 H2  %10.5lf%10.5lf%10.5lf WAT  %-5d  0.00000\n", 
			nAtom+3, ResBase, H2_Wat_x, H2_Wat_y, H2_Wat_z, Water_Count+1);
		nAtom += 3;
		ResBase++;
	}

	fclose(fOut);
}

void Get_EXE_Path(char szExeFile[], char szExePath[])
{
	FILE *fIn;
	char szLine[256], szBuff[256], *ReadLine, ErrorMsg[256];
	int nLen;

	fIn = fopen(szMyPath, "r");
	if(fIn == NULL)	{
		sprintf(ErrorMsg, "Fail to open file: %s\nQuit\n", szMyPath);
		Quit_With_Error_Msg(ErrorMsg);
	}

	nLen = strlen(szExeFile);
	while(1)	{
		if(feof(fIn))	{
			sprintf(ErrorMsg, "Fail to find the path of %s in %s\nQuit\n", szExeFile, szMyPath);
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}

		ReadLine = fgets(szLine, 256, fIn);

		if(ReadLine == NULL)	{
			sprintf(ErrorMsg, "Fail to find the path of %s in %s\nQuit\n", szExeFile, szMyPath);
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}
		else	{
			if(strncmp(szLine, szExeFile, nLen)==0)	{
				sscanf(szLine, "%s %s", szBuff, szExePath);
				break;
			}
		}
	}
	fclose(fIn);

	fIn = fopen(szExePath, "rb");
	if(fIn == NULL)	{
		sprintf(ErrorMsg, "The file %s for %s doesn't exist.\nQuit\n", szExePath, szExeFile);
//		Quit_With_Error_Msg(ErrorMsg);
	}
	else	{
		fclose(fIn);
	}
}

void Generate_Gaussian_Input(void)
{
	FILE *fOut;
	int i;

	fOut = fopen(szName_Gaussian, "w");
	fprintf(fOut, "%s", szQM_Level_Int_E_Dimer_Cmd);
	for(i=0; i<n_Atom_In_Mol; i++)	{
		fprintf(fOut, "%s  %10.5lf%10.5lf%10.5lf  1\n", szElemName[i], x_Mol[i], y_Mol[i], z_Mol[i]);
	}

	fprintf(fOut, "O  %10.5lf%10.5lf%10.5lf  2\n", O_Wat_x, O_Wat_y, O_Wat_z);
	fprintf(fOut, "H  %10.5lf%10.5lf%10.5lf  2\n", H1_Wat_x, H1_Wat_y, H1_Wat_z);
	fprintf(fOut, "H  %10.5lf%10.5lf%10.5lf  2\n\n", H2_Wat_x, H2_Wat_y, H2_Wat_z);
	
	fclose(fOut);
}

void Quit_With_Error_Msg(char szMsg[])
{
	FILE *fOut;
	fOut = fopen("../error.txt", "a+");
	fseek(fOut, 0, SEEK_END);
	fprintf(fOut, "Error in mol_H_acceptor.cpp\n");
	fprintf(fOut, "%s\n", szMsg);
	fclose(fOut);

	exit(1);
}


void Setup_QM_Level(void)
{
	FILE *fIn;
	char *ReadLine, szLine[256], szSubStr_1[256], szSubStr_2[256], ErrorMsg[256];
	char szKey_QM_MEM[256], szKey_QM_NPROC[256], szQM_Level_Opt[256], szQM_Level_Dimer_Opt[256], szQM_Level_ESP[256], szQM_Level_E_Dimer[256], szQM_Level_E_Monomer[256];
	int nStr, KeyCount;

	fIn = fopen(szQMParaFile, "r");
	if(fIn == NULL)	{
		sprintf(ErrorMsg, "Fail to open file %s\nQuit\n", szQMParaFile);
		Quit_With_Error_Msg(ErrorMsg);
	}

	KeyCount = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		Replace_NewLine(szLine);
		if(ReadLine == NULL)	{
			break;
		}
		else	{
			nStr = Split_Into_Two_String(szLine, szSubStr_1, szSubStr_2);
			if(nStr == 2)	{
				if(strcmp(szSubStr_1,"QM_MEM")==0)	{
					strcpy(szKey_QM_MEM, szSubStr_2);
					KeyCount++;
				}
				else if(strcmp(szSubStr_1,"QM_NPROC")==0)	{
					strcpy(szKey_QM_NPROC, szSubStr_2);
					KeyCount++;
					nCore_Per_Node = atoi(szKey_QM_NPROC);
				}
				else if(strcmp(szSubStr_1,"QM_LEVEL_OPT")==0)	{
					strcpy(szQM_Level_Opt, szSubStr_2);
					KeyCount++;
				}
				else if(strcmp(szSubStr_1,"QM_LEVEL_DIMER_OPT")==0)	{
					strcpy(szQM_Level_Dimer_Opt, szSubStr_2);
					KeyCount++;
				}
				else if(strcmp(szSubStr_1,"QM_LEVEL_ESP")==0)	{
					strcpy(szQM_Level_ESP, szSubStr_2);
					KeyCount++;
				}
				else if(strcmp(szSubStr_1,"QM_LEVEL_E_DIMER")==0)	{
					strcpy(szQM_Level_E_Dimer, szSubStr_2);
					KeyCount++;
				}
				else if(strcmp(szSubStr_1,"QM_LEVEL_E_MONOMER")==0)	{
					strcpy(szQM_Level_E_Monomer, szSubStr_2);
					KeyCount++;
				}
			}
		}
	}

	fclose(fIn);


	if(KeyCount != 7)	{	// !!!
		sprintf(ErrorMsg, "Setup_QM_Level> Error: incomplete entries in %s\nQuit\n", szQMParaFile);
		Quit_With_Error_Msg(ErrorMsg);
	}

	sprintf(szQM_Level_Int_E_Dimer_Cmd, "%%mem=%s%%nproc=%s%sMol-Water Dimer\n\n%d,1\n",
		szKey_QM_MEM, szKey_QM_NPROC, szQM_Level_E_Dimer, netcharge_mol);
	sprintf(szQM_Level_Int_E_Dimer_Opt_Cmd, "%%mem=%s%%nproc=%s%sMol-Water Dimer\n\n%d,1 \n",
		szKey_QM_MEM, szKey_QM_NPROC, szQM_Level_Dimer_Opt, netcharge_mol);
	sprintf(szQM_Level_Int_E_Single_Mol_Cmd, "%%mem=%s%%nproc=%s%s\n\nMol\n\n%d,1\n",
		szKey_QM_MEM, szKey_QM_NPROC, szQM_Level_E_Monomer, netcharge_mol);
	sprintf(szQM_Level_Int_E_Single_Wat_Cmd, "%%mem=%s%%nproc=%s%s\n\nWater\n\n0,1\n",
		szKey_QM_MEM, szKey_QM_NPROC, szQM_Level_E_Monomer);
}

int Split_Into_Two_String(char szBuff[], char str1[], char str2[])
{
	int nLen, i, iBegin_First, Count, iBegin_Second, nLen_1, nLen_2;

	nLen = strlen(szBuff);
	str1[0] = 0;
	str2[0] = 0;

	for(i=0; i<nLen; i++)	{
		if( (szBuff[i] != ' ') && (szBuff[i] != '\t') ) 	{	// To find the first character of the first string
			break;
		}
	}

	iBegin_First = i;

	Count = 0;
	for(i=iBegin_First; i<nLen; i++)	{
		if( (szBuff[i] == ' ') || (szBuff[i] == '\t') ) 	{	// To find the last character of the first string
			break;
		}
		else	{
			str1[Count] = szBuff[i];
			Count++;
		}
	}
	str1[Count] = 0;
	nLen_1 = Count;

	for(; i<nLen; i++)	{
		if( (szBuff[i] != ' ') && (szBuff[i] != '\t')  && (szBuff[i] != 0x22) ) 	{	// To find the first character of the second string
			break;
		}
	}
	iBegin_Second = i;

	Count = 0;
	for(i=iBegin_Second; i<nLen; i++)	{
		if( (szBuff[i] == 0x0) || (szBuff[i] == 0x22) ) 	{	// To find the last character of the second string
//		if( (szBuff[i] == 0x0) || (szBuff[i] == 0x0D) || (szBuff[i] == 0x0A) || (szBuff[i] == 0x22) ) 	{	// To find the last character of the second string
			break;
		}
		else	{
			str2[Count] = szBuff[i];
			Count++;
		}
	}
	str2[Count] = 0;
	nLen_2 = Count;

	if(nLen_2 > 0)	{
		return 2;
	}
	else if(nLen_1 > 0)	{
		return 1;
	}
	else	{
		return 0;
	}
}

void Replace_NewLine(char szBuff[])
{
	int nLen, i;

	nLen =strlen(szBuff);

	for(i=1; i<nLen; i++)	{
		if( (szBuff[i-1]==0x5C) && (szBuff[i]==0x6E) )	{
			szBuff[i-1] = 0x20;
			szBuff[i] = 0x0A;
		}
	}
}

void Get_Netcharge_From_Xpsf(void)
{
	int i, nAtom;
	double cg_sum=0.0;
	char szCharge[16];

	nAtom = Mol.nAtom;
	for(i=0; i<nAtom; i++)	{
		cg_sum += Mol.CG[i];
	}
	sprintf(szCharge, "%.0lf", cg_sum);

	netcharge_mol = atoi(szCharge);	// assuming the netcharge is an integer !!!
}


int To_Find_Tag(FILE *fIn, char szFileName[], char szTag[], char szLine[])
{
	char *ReadLine, ErrorMsg[256];

	while(1)	{
		if(feof(fIn))	{
			sprintf(ErrorMsg, "Fail to find the tag: %s in file %s\nQuit\n", szTag, szFileName);
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}

		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			sprintf(ErrorMsg, "Fail to find the tag: %s in file %s\nQuit\n", szTag, szFileName);
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}
		else	{
			if(FindString(szLine, szTag) >= 0)	{
				return 1;
			}
		}
	}

	return 0;
}

int Skip_N_Line(FILE *fIn, char szFileName[], int n)
{
	int i;
	char szLine[256], *ReadLine, ErrorMsg[256];

	for(i=0; i<n; i++)	{
		if(feof(fIn))	{
			sprintf(ErrorMsg, "Fail in Skip_N_Line(%s, %d).\nQuit\n", szFileName, n);
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}

		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			sprintf(ErrorMsg, "Fail in Skip_N_Line(%s, %d).\nQuit\n", szFileName, n);
			fclose(fIn);
			Quit_With_Error_Msg(ErrorMsg);
		}
	}
	return 1;
}

void ReadPreviousCG(void)
{
	FILE *fIn;
	int nAtom, i;

	fIn = fopen(szCGList, "r");
	if(fIn == NULL)	{
		return;
	}
	nAtom = Dimer.nAtom - 3;
	for(i=0; i<nAtom; i++)	{
		fscanf(fIn, "%lf", &(Dimer.CG[i]));
		Mol.CG[i] = Dimer.CG[i];	// assign same charges
	}
	fclose(fIn);

	Mol.Setup_NonBondParameters();
	Dimer.Setup_NonBondParameters();
	
	printf("Read previous charges.\n");
}



double CalRMSD(double *xa, double *ya, double *za, double *xb, double *yb, double *zb, int AtomNum)
{
	double RMSD, midxa, midya, midza, midxb, midyb, midzb;
	double xa_tmp[MAX_ATOM], ya_tmp[MAX_ATOM], za_tmp[MAX_ATOM];
	double xb_tmp[MAX_ATOM], yb_tmp[MAX_ATOM], zb_tmp[MAX_ATOM];
	int i, iMax;

	memcpy(xa_tmp+1, xa, sizeof(double)*AtomNum);
	memcpy(ya_tmp+1, ya, sizeof(double)*AtomNum);
	memcpy(za_tmp+1, za, sizeof(double)*AtomNum);

	memcpy(xb_tmp+1, xb, sizeof(double)*AtomNum+3);	// water is included
	memcpy(yb_tmp+1, yb, sizeof(double)*AtomNum+3);	// water is included
	memcpy(zb_tmp+1, zb, sizeof(double)*AtomNum+3);	// water is included


	midxa=midya=midza=midxb=midyb=midzb=0.0;
	for(i=1; i<=AtomNum; i++)	{
		midxa += (xa_tmp[i]);
		midya += (ya_tmp[i]);
		midza += (za_tmp[i]);

		midxb += (xb_tmp[i]);
		midyb += (yb_tmp[i]);
		midzb += (zb_tmp[i]);
	}
	midxa/=AtomNum;
	midya/=AtomNum;
	midza/=AtomNum;
	midxb/=AtomNum;
	midyb/=AtomNum;
	midzb/=AtomNum;

	for(i=1; i<=AtomNum; i++)	{
		xa_tmp[i]-=midxa;
		ya_tmp[i]-=midya;
		za_tmp[i]-=midza;
	}
	iMax = AtomNum+3;
	for(i=1; i<=iMax; i++)	{
		xb_tmp[i]-=midxb;
		yb_tmp[i]-=midyb;
		zb_tmp[i]-=midzb;
	}

	quatfit(xa_tmp, ya_tmp, za_tmp, xb_tmp, yb_tmp, zb_tmp, AtomNum);
	RMSD=rmsfit(xa_tmp, ya_tmp, za_tmp, xb_tmp, yb_tmp, zb_tmp, AtomNum);

	for(i=1; i<=iMax; i++)	{	// generate the rotated coodinates
		xb[i-1]=midxb+xb_tmp[i];
		yb[i-1]=midyb+yb_tmp[i];
		zb[i-1]=midzb+zb_tmp[i];
	}


	return RMSD;
}

double rmsfit (double *x1, double *y1, double *z1, double *x2, double *y2, double *z2, int n)
{
	int ia;
	double rmsfit, dist2, dx, dy, dz;

	rmsfit=0.0;
	for(ia=1; ia<=n; ia++)	{	//store xi-x0 into xStd[]
		dx = x1[ia] - x2[ia];
		dy = y1[ia] - y2[ia];
		dz = z1[ia] - z2[ia];
		dist2 = dx*dx + dy*dy + dz*dz;
		rmsfit += dist2;
	}
	rmsfit = sqrt(rmsfit/n);

	return rmsfit;
}

void quatfit (double *x1, double *y1, double *z1, double *x2, double *y2, double *z2, int n)
{
	double xxyx,xxyy,xxyz, xyyx,xyyy,xyyz, xzyx,xzyy,xzyz;
	double xrot,yrot,zrot, work1[5],work2[5], q[5],d[5], rot[4][4], c[5][5], v[5][5];
	int ia, ia_Max;

	xxyx = 0.0;
	xxyy = 0.0;
	xxyz = 0.0;
	xyyx = 0.0;
	xyyy = 0.0;
	xyyz = 0.0;
	xzyx = 0.0;
	xzyy = 0.0;
	xzyz = 0.0;

	for(ia=1; ia<=n; ia++)	{
		xxyx = xxyx + x1[ia]*x2[ia];
		xxyy = xxyy + y1[ia]*x2[ia];
		xxyz = xxyz + z1[ia]*x2[ia];
		xyyx = xyyx + x1[ia]*y2[ia];
		xyyy = xyyy + y1[ia]*y2[ia];
		xyyz = xyyz + z1[ia]*y2[ia];
		xzyx = xzyx + x1[ia]*z2[ia];
		xzyy = xzyy + y1[ia]*z2[ia];
		xzyz = xzyz + z1[ia]*z2[ia];
	}

	c[1][1] = xxyx + xyyy + xzyz;
	c[1][2] = xzyy - xyyz;
	c[2][2] = xxyx - xyyy - xzyz;
	c[1][3] = xxyz - xzyx;
	c[2][3] = xxyy + xyyx;
	c[3][3] = xyyy - xzyz - xxyx;
	c[1][4] = xyyx - xxyy;
	c[2][4] = xzyx + xxyz;
	c[3][4] = xyyz + xzyy;
	c[4][4] = xzyz - xxyx - xyyy;
	
	jacobi(4,4,c,d,v,work1,work2);
	q[1] = v[1][4];
	q[2] = v[2][4];
	q[3] = v[3][4];
	q[4] = v[4][4];

	rot[1][1] = q[1]*q[1] + q[2]*q[2] - q[3]*q[3] - q[4]*q[4];
	rot[2][1] = 2.0 * (q[2] * q[3] - q[1] * q[4]);
	rot[3][1] = 2.0 * (q[2] * q[4] + q[1] * q[3]);
	rot[1][2] = 2.0 * (q[3] * q[2] + q[1] * q[4]);
	rot[2][2] = q[1]*q[1] - q[2]*q[2] + q[3]*q[3] - q[4]*q[4];
	rot[3][2] = 2.0 * (q[3] * q[4] - q[1] * q[2]);
	rot[1][3] = 2.0 * (q[4] * q[2] - q[1] * q[3]);
	rot[2][3] = 2.0 * (q[4] * q[3] + q[1] * q[2]);
	rot[3][3] = q[1]*q[1] - q[2]*q[2] - q[3]*q[3] + q[4]*q[4];

	ia_Max = n+3;	// include water
//	for(ia=1; ia<=n; ia++)	{
	for(ia=1; ia<=ia_Max; ia++)	{
		xrot = x2[ia]*rot[1][1] + y2[ia]*rot[1][2] + z2[ia]*rot[1][3];
		yrot = x2[ia]*rot[2][1] + y2[ia]*rot[2][2] + z2[ia]*rot[2][3];
		zrot = x2[ia]*rot[3][1] + y2[ia]*rot[3][2] + z2[ia]*rot[3][3];
		x2[ia] = xrot;
		y2[ia] = yrot;
		z2[ia] = zrot;
	}

	return;
}


#define ZERO			(1.0E-100)
void jacobi (int n, int np, double a[5][5], double d[5], double v[5][5], double b[5], double z[5])
{
	int i,j,k;
	int ip,iq;
	int nrot,maxrot;
	double sm,tresh,s,c,t;
	double theta,tau,h,g,p;
	
	maxrot = 100;
	nrot = 0;
	
	for(ip=1; ip<=n; ip++)	{
		for(iq=1; iq<=n; iq++)	{
			v[ip][iq] = 0.0;
		}
		v[ip][ip] = 1.0;
	}
	for(ip=1; ip<=n; ip++)	{
		b[ip] = a[ip][ip];
		d[ip] = b[ip];
		z[ip] = 0.0;
	}
	
	
	for(i=1; i<=maxrot; i++)	{
		sm=0.0;
		for(ip=1; ip<=(n-1); ip++)	{
			for(iq=ip+1; iq<=n; iq++)	{
				sm = sm + fabs(a[ip][iq]);
			}
		}
		
		if(sm < ZERO)	{	//converge
			break;
		}
		if(i < 4)	{
			tresh = 0.2*sm / (n*n);
		}
		else	{
			tresh=0.0;
		}
		
		for(ip=1; ip<=(n-1); ip++)	{
			for(iq=ip+1; iq<=n; iq++)	{
				g = 100.0 * fabs(a[ip][iq]);
				if((i > 4) && (fabs(g) < ZERO))	{
					a[ip][iq] = 0.0;
				}
				else if(fabs(a[ip][iq]) > tresh)	{
					h = d[iq] - d[ip];
					if(fabs(g) < ZERO)	{
						t = a[ip][iq] / h;
					}
					else	{
						theta = 0.5*h / a[ip][iq];
						t = 1.0 / (fabs(theta)+sqrt(1.0+theta*theta));
						if (theta < 0.0)  t = -t;
					}
					
					c = 1.0 / sqrt(1.0+t*t);
					s = t * c;
					tau = s / (1.0+c);
					h = t * a[ip][iq];
					z[ip] = z[ip] - h;
					z[iq] = z[iq] + h;
					d[ip] = d[ip] - h;
					d[iq] = d[iq] + h;
					a[ip][iq] = 0.0;
					
					for(j=1; j<=(ip-1); j++)	{
						g = a[j][ip];
						h = a[j][iq];
						a[j][ip] = g - s*(h+g*tau);
						a[j][iq] = h + s*(g-h*tau);
					}
					for(j=ip+1; j<=(iq-1); j++)	{
						g = a[ip][j];
						h = a[j][iq];
						a[ip][j] = g - s*(h+g*tau);
						a[j][iq] = h + s*(g-h*tau);
					}
					for(j=iq+1; j<=n; j++)	{
						g = a[ip][j];
						h = a[iq][j];
						a[ip][j] = g - s*(h+g*tau);
						a[iq][j] = h + s*(g-h*tau);
					}
					for(j=1; j<=n; j++)	{
						g = v[j][ip];
						h = v[j][iq];
						v[j][ip] = g - s*(h+g*tau);
						v[j][iq] = h + s*(g-h*tau);
					}
					nrot = nrot + 1;
				}
			}
		}
		for(ip=1; ip<=n; ip++)	{
            b[ip] = b[ip] + z[ip];
            d[ip] = b[ip];
            z[ip] = 0.0;
		}
	}
	if(nrot >= maxrot)	{
		printf("JACOBI  --  Matrix Diagonalization not Converged.\n");
	}

	for(i=1; i<= (n-1); i++)	{
         k = i;
         p = d[i];
		 for(j=i+1; j<=n; j++)	{
			 if(d[j] < p)	{
               k = j;
               p = d[j];
			 }
		 }
		 if(k != i)	{
            d[k] = d[i];
            d[i] = p;
			for(j=1; j<=n; j++)	{
               p = v[j][i];
               v[j][i] = v[j][k];
               v[j][k] = p;
			}
		 }
	}
}
#undef	ZERO

double Cal_Dist_Two_Atoms(int ia, int ib)
{
	double dx, dy, dz, r;

	dx = Dimer.x[ia] - Dimer.x[ib];
	dy = Dimer.y[ia] - Dimer.y[ib];
	dz = Dimer.z[ia] - Dimer.z[ib];
	r = sqrt(dx*dx + dy*dy + dz*dz);
	return r;
}

void SaveDummyAtoms(void)
{
	x_Dummy_1_Save = x_Dummy_1;
	y_Dummy_1_Save = y_Dummy_1;
	z_Dummy_1_Save = z_Dummy_1;
	
	x_Dummy_2_Save = x_Dummy_2;
	y_Dummy_2_Save = y_Dummy_2;
	z_Dummy_2_Save = z_Dummy_2;
	
	v_x_X1_Acceptor_Save = v_x_X1_Acceptor;
	v_y_X1_Acceptor_Save = v_y_X1_Acceptor;
	v_z_X1_Acceptor_Save = v_z_X1_Acceptor;
}

void RestoreDummyAtoms(void)
{
	x_Dummy_1 = x_Dummy_1_Save;
	y_Dummy_1 = y_Dummy_1_Save;
	z_Dummy_1 = z_Dummy_1_Save;
	                          
	x_Dummy_2 = x_Dummy_2_Save;
	y_Dummy_2 = y_Dummy_2_Save;
	z_Dummy_2 = z_Dummy_2_Save;
	
	v_x_X1_Acceptor = v_x_X1_Acceptor_Save;
	v_y_X1_Acceptor = v_y_X1_Acceptor_Save;
	v_z_X1_Acceptor = v_z_X1_Acceptor_Save;
}



void CWORKER::Start_Job(int CoreNum, int ID, char szGjf[], char szOut[])
{
	char szCmd[256], szEnv[256], szErrorMsg[256];
	FILE *fIn;

	nCore = CoreNum;
	Status = BUSY;
	
	JobID = ID;
	strcpy(szInput, szGjf);
	strcpy(szOutput, szOut);

	sprintf(szEnv, "%s/%d", szGAUSS_SCRDIR_Base, ID);
#ifdef WIN32
	if( SetEnvironmentVariable(szGAUSS_SCRDIR, szEnv) == 0) {
#else
	if (setenv(szGAUSS_SCRDIR, szEnv, 1) < 0) {
#endif
		sprintf(szErrorMsg, "Error setting env for %s with ID = %d.\n", szGAUSS_SCRDIR, ID);
		Quit_With_Error_Msg(szErrorMsg);
	}

	sprintf(szCmd, "mkdir %s", szEnv);
	system(szCmd);

	chdir(szDirList[ID]);

	Update_Core_Number_Input_File();
	
	sprintf(szCmd, "%s < %s > %s &", szExe_G09, szInput, szOutput);

	fIn = fopen(szOutput, "r");
	if(fIn == NULL)	{
		system(szCmd);
	}
	else	{
		fclose(fIn);
		Get_Job_Status();
	}
}

#define SIZE_CHECK	(512)
int CWORKER::Get_Job_Status(void)
{
	FILE *fIn;
	char szErrorMsg[256], szBuff[1024];
	int i, nLen;

	if(Status == IDLE)	{
		return Status;
	}

	fIn = fopen(szOutput, "rb");

	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Error in open file %s for reading.\nQuit\n", szOutput);
		Quit_With_Error_Msg(szErrorMsg);
	}

	fseek(fIn, -SIZE_CHECK, SEEK_END);

	nLen = fread(szBuff, 1, SIZE_CHECK, fIn);

	for(i=0; i<nLen; i++)	{
		if(strncmp(szBuff+i, "Job cpu time:", 13) == 0)	{
			fclose(fIn);

			JobStatus[JobID] = Job_Done;
			Status = IDLE;
			nJobDone++;
			return Status;
		}
	}

	fclose(fIn);

	Status = BUSY;
	return Status;
}
#undef SIZE_CHECK

void CWORKER::Update_Core_Number_Input_File(void)
{
	FILE *fIn, *fOut;
	char szErrorMsg[256], szNewName[]="new.gjf", szLine[256], *ReadLine, szCmd[256];;

	fIn = fopen(szInput, "r");

	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Fail to open input file %s\nQuit\n", szInput);
		Quit_With_Error_Msg(szErrorMsg);
	}

	fOut = fopen(szNewName, "w");

	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		else	{
			if(strncmp(szLine, "%nproc", 6)==0)	{
				sprintf(szLine, "%s%d\n", "%nproc=", nCore);
			}

			fprintf(fOut, "%s", szLine);
		}
	}


	fclose(fIn);
	fclose(fOut);

	sprintf(szCmd, "mv %s %s", szNewName, szInput);
	system(szCmd);
}

int Count_Finished_Job()
{
	int i, Count=0;

	for(i=0; i<nJob; i++)	{
		if(JobStatus[i] == Job_Done)	{
			Count++;
		}
	}

	return Count;
}

void RunAllJobs(void)
{
	int i, Idx_Worker, CoreNum, nJob_Submitted=0;
	int CoreNum_List[]={12, 6, 4, 3, 4, 2, 3, 3, 4, 4, 4, 2, 4, 4, 4, 3};	// for 12 cores
//	int CoreNum_List[]={24, 16, 10, 8, 6, 5, 4, 4, 3, 3, 5, 5, 4, 4, 4, 4};	// for 32 cores

	if(nJob > 16)	{
		CoreNum = 4;
	}
	else	{
		CoreNum = CoreNum_List[nJob-1];
		if(nJob == 0)	{
			CoreNum = 1;
		}
	}
	nWorker = nCore_Per_Node / CoreNum;
	if(nWorker == 0)	{
		nWorker = 1;
	}
	pWorker = new CWORKER[nWorker];

	for(i=0; i<nJob; i++)	{
		JobStatus[i] = Job_ToRun;
	}

	for(i=0; i<nWorker; i++)	{
		pWorker[i].Status = IDLE;
	}

	nJob_Submitted = 0;
	while( nJobDone < nJob)	{
		if(Count_Finished_Job() == nJob)	{
			break;
		}
		Idx_Worker = Get_First_Available_Worker();
		if( (Idx_Worker >= 0) && (nJob_Submitted < nJob) )	{
			pWorker[Idx_Worker].Start_Job(CoreNum, nJob_Submitted, szInputList[nJob_Submitted], szOutputList[nJob_Submitted]);
			nJob_Submitted++;
			system("sleep 3");
		}
		else	{
			system("sleep 8");
		}
	}

	delete []pWorker;
}

int Get_First_Available_Worker(void)	// to check the status for all workers
{
	int iFirst=-1;

	for(int i=0; i<nWorker; i++)	{
		if(pWorker[i].Get_Job_Status() == IDLE)	{
			if(iFirst < 0)	{
				iFirst = i;
			}
		}
	}

	return iFirst;
}


