#!/bin/bash


mpicxx -O2 -o 1d-org 1D-fitting.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a

cp 1d-org ..
chmod g+rx ../1d-org

