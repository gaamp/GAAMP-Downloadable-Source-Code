#!/bin/bash


mpicxx -O3 -o 1d-rotamer-fitting 1D-rotamer-fitting.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a 

cp 1d-rotamer-fitting ..
chmod g+rx ../1d-rotamer-fitting
