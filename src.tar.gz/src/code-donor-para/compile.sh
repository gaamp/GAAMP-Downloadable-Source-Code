#!/bin/bash


icc -O3 -o donor_para mol_H_donor.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a -static

cp donor_para ..
chmod g+rx ../donor_para
