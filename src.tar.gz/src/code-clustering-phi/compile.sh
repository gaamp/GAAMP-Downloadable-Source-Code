#!/bin/bash

g++ -O3 -o clustering-phi clustering.cpp -static

cp clustering-phi ..
chmod g+rx ../clustering-phi
