#!/bin/bash


g++ -O3 -o check_lj modify_lj.cpp -static

cp check_lj ..
chmod g+rx ../check_lj

