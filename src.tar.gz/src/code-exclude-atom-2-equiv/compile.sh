#!/bin/bash

g++ -O2 -o exclude_H2 exclude-H2.cpp -static

cp exclude_H2 ..
chmod g+rx ../exclude_H2
