#!/bin/bash

g++ -O3 -o cut_LJ14 cut-LJ14.cpp -static

cp cut_LJ14 ..
chmod g+rx ../cut_LJ14
