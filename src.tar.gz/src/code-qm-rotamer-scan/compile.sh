#!/bin/bash

export PATH=/gpfs2/software/SLEZ9-x86_64/com/packages/intel-11.1.064/bin/intel64:/gpfs1/home/huanglei/tools/mpich-intel/bin:$PATH
export LD_LIBRARY_PATH=/gpfs2/software/SLEZ9-x86_64/com/packages/intel-11.1.064/lib/intel64:/gpfs1/home/huanglei/tools/mpich-intel/lib:$LD_LIBRARY_PATH

mpicxx -O3 -o qm-rotamer-scan QM_rotamer_scan.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a -static

cp qm-rotamer-scan ..
chmod g+rx ../qm-rotamer-scan
