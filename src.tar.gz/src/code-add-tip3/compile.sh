#!/bin/bash

g++ -O3 -o add-tip3 add_tip3.cpp -static

cp add-tip3 ..
chmod g+rx ../add-tip3
