#!/bin/bash


mpicxx -O3 -o 1d-fitting 1D-fitting.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a 

cp 1d-fitting ..
chmod g+rx ../1d-fitting
