#!/bin/bash


icc -O3 -o fitcharge fitcharge.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a -static

cp fitcharge ..
chmod g+rx ../fitcharge
