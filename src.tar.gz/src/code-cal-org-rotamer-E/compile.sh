#!/bin/bash


mpicxx -O2 -o org-rotamer-E 1D-rotamer-fitting.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a 

cp org-rotamer-E ..
chmod g+rx ../org-rotamer-E

