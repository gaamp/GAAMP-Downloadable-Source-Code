#!/bin/bash

g++ -O2 -o prep_cgenff extract_param.cpp ff.cpp -static

cp prep_cgenff ..
chmod g+rx ../prep_cgenff
