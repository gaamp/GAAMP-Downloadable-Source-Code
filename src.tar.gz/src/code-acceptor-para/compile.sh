#!/bin/bash


icc -O3 -o acceptor_para mol_H_acceptor.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a -static

cp acceptor_para ..
chmod g+rx ../acceptor_para
