#!/bin/bash

g++ -O3 -o check-b0-theta0 check_b0_theta0.cpp ff.cpp -static

cp check-b0-theta0 ..
chmod g+rx ../check-b0-theta0
