#!/bin/bash


icc -O3 -o acceptor mol_H_acceptor.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a -static

cp acceptor ..
chmod g+rx ../acceptor
