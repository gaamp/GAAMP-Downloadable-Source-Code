#!/bin/bash

export PATH=/gpfs2/software/SLEZ9-x86_64/com/packages/intel-11.1.064/bin/intel64:/gpfs1/home/huanglei/tools/mpich-intel/bin:$PATH
export LD_LIBRARY_PATH=/gpfs2/software/SLEZ9-x86_64/com/packages/intel-11.1.064/lib/intel64:/gpfs1/home/huanglei/tools/mpich-intel/lib:$LD_LIBRARY_PATH

icc -O3 -o update-tor-para update-torsion-para.cpp ff.cpp ~/tools/mynlopt/nlopt-2.2.4/.libs/libnlopt.a -static

cp update-tor-para ..
chmod g+rx ../update-tor-para
