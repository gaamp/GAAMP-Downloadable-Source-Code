#!/bin/bash

g++ -O2 -o pdb_to_crd pdb_to_crd.cpp ff.cpp -static

cp pdb_to_crd ..
chmod g+rx ../pdb_to_crd
