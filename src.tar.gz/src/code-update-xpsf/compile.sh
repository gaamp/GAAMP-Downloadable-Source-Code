#!/bin/bash

g++ -O3 -o update-xpsf update-xpsf.cpp -static

cp update-xpsf ..
chmod g+rx ../update-xpsf
