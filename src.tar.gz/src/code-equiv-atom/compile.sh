#!/bin/bash

g++ -O2 -o equiv_atom equiv_atom.cpp -static

cp equiv_atom ..
chmod g+rx ../equiv_atom
