#!/bin/bash

g++ -O3 -o gen-esp gen-esp.cpp -static

cp gen-esp ..
chmod g+rx ../gen-esp
